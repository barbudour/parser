# GroupPosition.Inequality - оператор

##  __Definition

 **Пространство имён:**
[Tessa.Extensions.Default.Shared.Workflow.KrCompilers](N_Tessa_Extensions_Default_Shared_Workflow_KrCompilers.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public static bool operator !=(
    	GroupPosition first,
    	GroupPosition second
    )

VB __Копировать

    
    
     Public Shared Operator <> ( 
    	first As GroupPosition,
    	second As GroupPosition
    ) As Boolean

C++ __Копировать

    
    
     public:
    static bool operator !=(
    	GroupPosition first, 
    	GroupPosition second
    )

F# __Копировать

    
    
     static let inline (<>)
            first : GroupPosition * 
            second : GroupPosition  : bool

#### Параметры

first
[GroupPosition](T_Tessa_Extensions_Default_Shared_Workflow_KrCompilers_GroupPosition.htm)

    
second
[GroupPosition](T_Tessa_Extensions_Default_Shared_Workflow_KrCompilers_GroupPosition.htm)

    

#### Возвращаемое значение

[Boolean](https://learn.microsoft.com/dotnet/api/system.boolean)

##  __См. также

#### Ссылки

[GroupPosition -
](T_Tessa_Extensions_Default_Shared_Workflow_KrCompilers_GroupPosition.htm)

[Tessa.Extensions.Default.Shared.Workflow.KrCompilers - пространство
имён](N_Tessa_Extensions_Default_Shared_Workflow_KrCompilers.htm)

