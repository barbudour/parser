# WorkflowTaskWorker<TManager> \- свойства

##  __Свойства

[CardRepositoryToCreateTasks](P_Tessa_Cards_Workflow_WorkflowTaskWorker_1_CardRepositoryToCreateTasks.htm)|
Репозиторий карточек, используемый для создания карточек заданий.  
---|---  
[Manager](P_Tessa_Cards_Workflow_WorkflowWorker_1_Manager.htm)| Объект,
предоставляющий возможности для управления бизнес-процессом.  
(Унаследован от
[WorkflowWorker<TManager>](T_Tessa_Cards_Workflow_WorkflowWorker_1.htm))  
  
##  __См. также

#### Ссылки

[WorkflowTaskWorker<TManager> \-
](T_Tessa_Cards_Workflow_WorkflowTaskWorker_1.htm)

[Tessa.Cards.Workflow - пространство имён](N_Tessa_Cards_Workflow.htm)

