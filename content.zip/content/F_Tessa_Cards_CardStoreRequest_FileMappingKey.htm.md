# CardStoreRequest.FileMappingKey - поле

##  __Definition

 **Пространство имён:** [Tessa.Cards](N_Tessa_Cards.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public const string FileMappingKey = "FileMapping"

VB __Копировать

    
    
     Public Const FileMappingKey As String = "FileMapping"

C++ __Копировать

    
    
     public:
    literal String^ FileMappingKey = "FileMapping"

F# __Копировать

    
    
     static val mutable FileMappingKey: string

#### Значение поля

[String](https://learn.microsoft.com/dotnet/api/system.string)

##  __См. также

#### Ссылки

[CardStoreRequest - ](T_Tessa_Cards_CardStoreRequest.htm)

[Tessa.Cards - пространство имён](N_Tessa_Cards.htm)

