# BusinessCalendarHelper.DateTimeEndKey - поле

Ключ, задающий окончание временного интервала.

## __Definition

 **Пространство имён:** [Tessa.BusinessCalendar](N_Tessa_BusinessCalendar.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public const string DateTimeEndKey = ".dateTimeEnd"

VB __Копировать

    
    
     Public Const DateTimeEndKey As String = ".dateTimeEnd"

C++ __Копировать

    
    
     public:
    literal String^ DateTimeEndKey = ".dateTimeEnd"

F# __Копировать

    
    
     static val mutable DateTimeEndKey: string

#### Значение поля

[String](https://learn.microsoft.com/dotnet/api/system.string)

##  __См. также

#### Ссылки

[BusinessCalendarHelper -
](T_Tessa_BusinessCalendar_BusinessCalendarHelper.htm)

[Tessa.BusinessCalendar - пространство имён](N_Tessa_BusinessCalendar.htm)

