# CardHelper.ErrorTypeID - поле

Card type identifier for "Error": {FA81208D-2D83-4CB6-A83D-CBA7E3F483A7}.

## __Definition

 **Пространство имён:** [Tessa.Cards](N_Tessa_Cards.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public static readonly Guid ErrorTypeID

VB __Копировать

    
    
     Public Shared ReadOnly ErrorTypeID As Guid

C++ __Копировать

    
    
     public:
    static initonly Guid ErrorTypeID

F# __Копировать

    
    
     static val ErrorTypeID: Guid

#### Значение поля

[Guid](https://learn.microsoft.com/dotnet/api/system.guid)

##  __См. также

#### Ссылки

[CardHelper - ](T_Tessa_Cards_CardHelper.htm)

[Tessa.Cards - пространство имён](N_Tessa_Cards.htm)

