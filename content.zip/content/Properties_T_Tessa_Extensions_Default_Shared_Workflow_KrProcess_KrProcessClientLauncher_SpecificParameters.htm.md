# SpecificParameters - свойства

##  __Свойства

[RaiseErrorWhenExecutionIsForbidden](P_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrProcessLauncherSpecificParametersBase_RaiseErrorWhenExecutionIsForbidden.htm)|
Возвращает или задаёт значение флага, показывающего, следует ли создавать
ошибку, если процесс не может быть выполнен из-за ограничений (параметр
вторичного процесса "Сообщение при невозможности выполнения процесса").  
(Унаследован от
[KrProcessLauncherSpecificParametersBase](T_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrProcessLauncherSpecificParametersBase.htm))  
---|---  
[RequestInfo](P_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrProcessClientLauncherBaseSpecificParameters_RequestInfo.htm)|
Возвращает или задаёт дополнительную информацию, передаваемую в запросе на
сохранение карточки для расширений. Данные должны быть сериализуемых типов.
Может иметь значение по умолчанию для типа.  
(Унаследован от
[KrProcessClientLauncherBaseSpecificParameters](T_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrProcessClientLauncherBaseSpecificParameters.htm))  
  
##  __См. также

#### Ссылки

[KrProcessClientLauncher.SpecificParameters -
](T_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrProcessClientLauncher_SpecificParameters.htm)

[Tessa.Extensions.Default.Shared.Workflow.KrProcess - пространство
имён](N_Tessa_Extensions_Default_Shared_Workflow_KrProcess.htm)

