# ICardFileContentResult - методы

##  __Методы

[GetContentOrThrowAsync](M_Tessa_Cards_ICardFileContentResult_GetContentOrThrowAsync.htm)|
Возвращает поток с данными контента. Выбрасывает исключение, если данные
отсутствуют.  
---|---  
  
##  __См. также

#### Ссылки

[ICardFileContentResult - ](T_Tessa_Cards_ICardFileContentResult.htm)

[Tessa.Cards - пространство имён](N_Tessa_Cards.htm)

