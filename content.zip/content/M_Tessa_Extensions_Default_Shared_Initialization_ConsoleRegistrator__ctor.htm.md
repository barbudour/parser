# ConsoleRegistrator - конструктор

Инициализирует новый экземпляр класса
[ConsoleRegistrator](T_Tessa_Extensions_Default_Shared_Initialization_ConsoleRegistrator.htm)

##  __Definition

 **Пространство имён:**
[Tessa.Extensions.Default.Shared.Initialization](N_Tessa_Extensions_Default_Shared_Initialization.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public ConsoleRegistrator()

VB __Копировать

    
    
     Public Sub New

C++ __Копировать

    
    
     public:
    ConsoleRegistrator()

F# __Копировать

    
    
     new : unit -> ConsoleRegistrator

##  __См. также

#### Ссылки

[ConsoleRegistrator -
](T_Tessa_Extensions_Default_Shared_Initialization_ConsoleRegistrator.htm)

[Tessa.Extensions.Default.Shared.Initialization - пространство
имён](N_Tessa_Extensions_Default_Shared_Initialization.htm)

