# ActionCompletionOptions.Disapproved - поле

Не согласовано.

## __Definition

 **Пространство имён:**
[Tessa.Extensions.Default.Shared.Workflow.WorkflowEngine](N_Tessa_Extensions_Default_Shared_Workflow_WorkflowEngine.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public static readonly Guid Disapproved

VB __Копировать

    
    
     Public Shared ReadOnly Disapproved As Guid

C++ __Копировать

    
    
     public:
    static initonly Guid Disapproved

F# __Копировать

    
    
     static val Disapproved: Guid

#### Значение поля

[Guid](https://learn.microsoft.com/dotnet/api/system.guid)

##  __См. также

#### Ссылки

[ActionCompletionOptions -
](T_Tessa_Extensions_Default_Shared_Workflow_WorkflowEngine_ActionCompletionOptions.htm)

[Tessa.Extensions.Default.Shared.Workflow.WorkflowEngine - пространство
имён](N_Tessa_Extensions_Default_Shared_Workflow_WorkflowEngine.htm)

