# TaskSatelliteImportExtension.ExtendedRepositoryWithoutTransaction - свойство

Репозиторий для управления карточками с расширениями и без транзакции.

## __Definition

 **Пространство имён:**
[Tessa.Cards.Extensions.Templates](N_Tessa_Cards_Extensions_Templates.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     protected ICardRepository ExtendedRepositoryWithoutTransaction { get; }

VB __Копировать

    
    
     Protected ReadOnly Property ExtendedRepositoryWithoutTransaction As ICardRepository
    	Get

C++ __Копировать

    
    
     protected:
    property ICardRepository^ ExtendedRepositoryWithoutTransaction {
    	ICardRepository^ get ();
    }

F# __Копировать

    
    
     member ExtendedRepositoryWithoutTransaction : ICardRepository with get

#### Значение свойства

[ICardRepository](T_Tessa_Cards_ICardRepository.htm)

##  __См. также

#### Ссылки

[TaskSatelliteImportExtension -
](T_Tessa_Cards_Extensions_Templates_TaskSatelliteImportExtension.htm)

[Tessa.Cards.Extensions.Templates - пространство
имён](N_Tessa_Cards_Extensions_Templates.htm)

