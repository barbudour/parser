# DefaultInitializationExtensionHelper - поля

##  __Поля

[KrTypeInfoKey](F_Tessa_Extensions_Default_Shared_DefaultInitializationExtensionHelper_KrTypeInfoKey.htm)|
Поле в ответе на запрос response.Info, содержащее информацию по типам карточек
и документов для типового решения.  
---|---  
  
## __См. также

#### Ссылки

[DefaultInitializationExtensionHelper -
](T_Tessa_Extensions_Default_Shared_DefaultInitializationExtensionHelper.htm)

[Tessa.Extensions.Default.Shared - пространство
имён](N_Tessa_Extensions_Default_Shared.htm)

