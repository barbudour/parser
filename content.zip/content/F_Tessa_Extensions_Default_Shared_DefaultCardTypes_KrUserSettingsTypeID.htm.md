# DefaultCardTypes.KrUserSettingsTypeID - поле

Card type identifier for "KrUserSettings":
{793864E5-39E5-4D4F-AF59-C3D7A9FACCA9}.

## __Definition

 **Пространство имён:**
[Tessa.Extensions.Default.Shared](N_Tessa_Extensions_Default_Shared.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public static readonly Guid KrUserSettingsTypeID

VB __Копировать

    
    
     Public Shared ReadOnly KrUserSettingsTypeID As Guid

C++ __Копировать

    
    
     public:
    static initonly Guid KrUserSettingsTypeID

F# __Копировать

    
    
     static val KrUserSettingsTypeID: Guid

#### Значение поля

[Guid](https://learn.microsoft.com/dotnet/api/system.guid)

##  __См. также

#### Ссылки

[DefaultCardTypes - ](T_Tessa_Extensions_Default_Shared_DefaultCardTypes.htm)

[Tessa.Extensions.Default.Shared - пространство
имён](N_Tessa_Extensions_Default_Shared.htm)

