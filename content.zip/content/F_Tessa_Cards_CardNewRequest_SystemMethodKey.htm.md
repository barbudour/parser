# CardNewRequest.SystemMethodKey - поле

##  __Definition

 **Пространство имён:** [Tessa.Cards](N_Tessa_Cards.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public const string SystemMethodKey = ".method"

VB __Копировать

    
    
     Public Const SystemMethodKey As String = ".method"

C++ __Копировать

    
    
     public:
    literal String^ SystemMethodKey = ".method"

F# __Копировать

    
    
     static val mutable SystemMethodKey: string

#### Значение поля

[String](https://learn.microsoft.com/dotnet/api/system.string)

##  __См. также

#### Ссылки

[CardNewRequest - ](T_Tessa_Cards_CardNewRequest.htm)

[Tessa.Cards - пространство имён](N_Tessa_Cards.htm)

