# DefaultNotifications.AdditionalApprovalNotificationCompleted - поле

Уведомление о завершении доп. согласования

## __Definition

 **Пространство имён:**
[Tessa.Extensions.Default.Shared](N_Tessa_Extensions_Default_Shared.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public static Guid AdditionalApprovalNotificationCompleted

VB __Копировать

    
    
     Public Shared AdditionalApprovalNotificationCompleted As Guid

C++ __Копировать

    
    
     public:
    static Guid AdditionalApprovalNotificationCompleted

F# __Копировать

    
    
     static val mutable AdditionalApprovalNotificationCompleted: Guid

#### Значение поля

[Guid](https://learn.microsoft.com/dotnet/api/system.guid)

##  __См. также

#### Ссылки

[DefaultNotifications -
](T_Tessa_Extensions_Default_Shared_DefaultNotifications.htm)

[Tessa.Extensions.Default.Shared - пространство
имён](N_Tessa_Extensions_Default_Shared.htm)

