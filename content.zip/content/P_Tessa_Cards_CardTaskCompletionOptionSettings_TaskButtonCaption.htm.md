# CardTaskCompletionOptionSettings.TaskButtonCaption - свойство

Возвращает или задаёт текст кнопки в задании.

## __Definition

 **Пространство имён:** [Tessa.Cards](N_Tessa_Cards.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public string? TaskButtonCaption { get; set; }

VB __Копировать

    
    
     Public Property TaskButtonCaption As String
    	Get
    	Set

C++ __Копировать

    
    
     public:
    property String^ TaskButtonCaption {
    	String^ get ();
    	void set (String^ value);
    }

F# __Копировать

    
    
     member TaskButtonCaption : string with get, set

#### Значение свойства

[String](https://learn.microsoft.com/dotnet/api/system.string)

##  __См. также

#### Ссылки

[CardTaskCompletionOptionSettings -
](T_Tessa_Cards_CardTaskCompletionOptionSettings.htm)

[Tessa.Cards - пространство имён](N_Tessa_Cards.htm)

