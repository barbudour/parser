# WorkflowConstants.UI.UseRoutesInWorkflowEngine - поле

##  __Definition

 **Пространство имён:**
[Tessa.Extensions.Default.Shared.Workflow.WorkflowEngine](N_Tessa_Extensions_Default_Shared_Workflow_WorkflowEngine.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public const string UseRoutesInWorkflowEngine = "UseRoutesInWorkflowEngine"

VB __Копировать

    
    
     Public Const UseRoutesInWorkflowEngine As String = "UseRoutesInWorkflowEngine"

C++ __Копировать

    
    
     public:
    literal String^ UseRoutesInWorkflowEngine = "UseRoutesInWorkflowEngine"

F# __Копировать

    
    
     static val mutable UseRoutesInWorkflowEngine: string

#### Значение поля

[String](https://learn.microsoft.com/dotnet/api/system.string)

##  __См. также

#### Ссылки

[WorkflowConstants.UI -
](T_Tessa_Extensions_Default_Shared_Workflow_WorkflowEngine_WorkflowConstants_UI.htm)

[Tessa.Extensions.Default.Shared.Workflow.WorkflowEngine - пространство
имён](N_Tessa_Extensions_Default_Shared_Workflow_WorkflowEngine.htm)

