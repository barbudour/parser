# CardSectionPermissionInfo.SectionPermissions - свойство

Права доступа на все поля секции.

## __Definition

 **Пространство имён:** [Tessa.Cards](N_Tessa_Cards.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public CardPermissionFlags SectionPermissions { get; set; }

VB __Копировать

    
    
     Public Property SectionPermissions As CardPermissionFlags
    	Get
    	Set

C++ __Копировать

    
    
     public:
    property CardPermissionFlags SectionPermissions {
    	CardPermissionFlags get ();
    	void set (CardPermissionFlags value);
    }

F# __Копировать

    
    
     member SectionPermissions : CardPermissionFlags with get, set

#### Значение свойства

[CardPermissionFlags](T_Tessa_Cards_CardPermissionFlags.htm)

##  __См. также

#### Ссылки

[CardSectionPermissionInfo - ](T_Tessa_Cards_CardSectionPermissionInfo.htm)

[Tessa.Cards - пространство имён](N_Tessa_Cards.htm)

