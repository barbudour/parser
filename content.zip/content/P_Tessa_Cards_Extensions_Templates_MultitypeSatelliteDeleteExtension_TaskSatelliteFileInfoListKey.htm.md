# MultitypeSatelliteDeleteExtension.TaskSatelliteFileInfoListKey - свойство

Уникальный ключ для информации по всем файлам карточки-сателлита
List<SatelliteInfo>, которые будут перенесены из основной карточки в
удалённую.

## __Definition

 **Пространство имён:**
[Tessa.Cards.Extensions.Templates](N_Tessa_Cards_Extensions_Templates.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     protected abstract string TaskSatelliteFileInfoListKey { get; }

VB __Копировать

    
    
     Protected MustOverride ReadOnly Property TaskSatelliteFileInfoListKey As String
    	Get

C++ __Копировать

    
    
     protected:
    virtual property String^ TaskSatelliteFileInfoListKey {
    	String^ get () abstract;
    }

F# __Копировать

    
    
     abstract TaskSatelliteFileInfoListKey : string with get

#### Значение свойства

[String](https://learn.microsoft.com/dotnet/api/system.string)

##  __См. также

#### Ссылки

[MultitypeSatelliteDeleteExtension -
](T_Tessa_Cards_Extensions_Templates_MultitypeSatelliteDeleteExtension.htm)

[Tessa.Cards.Extensions.Templates - пространство
имён](N_Tessa_Cards_Extensions_Templates.htm)

