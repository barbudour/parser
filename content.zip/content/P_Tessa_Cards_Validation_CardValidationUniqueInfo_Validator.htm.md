# CardValidationUniqueInfo.Validator - свойство

Валидатор, инициировавший проверку секции.

## __Definition

 **Пространство имён:** [Tessa.Cards.Validation](N_Tessa_Cards_Validation.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public CardTypeValidator Validator { get; }

VB __Копировать

    
    
     Public ReadOnly Property Validator As CardTypeValidator
    	Get

C++ __Копировать

    
    
     public:
    property CardTypeValidator^ Validator {
    	CardTypeValidator^ get ();
    }

F# __Копировать

    
    
     member Validator : CardTypeValidator with get

#### Значение свойства

[CardTypeValidator](T_Tessa_Cards_CardTypeValidator.htm)

##  __См. также

#### Ссылки

[CardValidationUniqueInfo -
](T_Tessa_Cards_Validation_CardValidationUniqueInfo.htm)

[Tessa.Cards.Validation - пространство имён](N_Tessa_Cards_Validation.htm)

