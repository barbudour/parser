# DefaultCardTypes.KrProcessManagementStageTypeSettingsTypeID - поле

Card type identifier for "KrProcessManagementStageTypeSettings":
{FF753641-0691-4CFC-A8CC-BAA89B25A83B}.

## __Definition

 **Пространство имён:**
[Tessa.Extensions.Default.Shared](N_Tessa_Extensions_Default_Shared.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public static readonly Guid KrProcessManagementStageTypeSettingsTypeID

VB __Копировать

    
    
     Public Shared ReadOnly KrProcessManagementStageTypeSettingsTypeID As Guid

C++ __Копировать

    
    
     public:
    static initonly Guid KrProcessManagementStageTypeSettingsTypeID

F# __Копировать

    
    
     static val KrProcessManagementStageTypeSettingsTypeID: Guid

#### Значение поля

[Guid](https://learn.microsoft.com/dotnet/api/system.guid)

##  __См. также

#### Ссылки

[DefaultCardTypes - ](T_Tessa_Extensions_Default_Shared_DefaultCardTypes.htm)

[Tessa.Extensions.Default.Shared - пространство
имён](N_Tessa_Extensions_Default_Shared.htm)

