# Tessa.Extensions.Default.Console.ExportWorkplaces - пространство имён

## __Классы

[Command](T_Tessa_Extensions_Default_Console_ExportWorkplaces_Command.htm)|  
---|---  
[CommandRegistrator](T_Tessa_Extensions_Default_Console_ExportWorkplaces_CommandRegistrator.htm)|  
[Operation](T_Tessa_Extensions_Default_Console_ExportWorkplaces_Operation.htm)|  
[OperationContext](T_Tessa_Extensions_Default_Console_ExportWorkplaces_OperationContext.htm)|  
[OperationRegistrator](T_Tessa_Extensions_Default_Console_ExportWorkplaces_OperationRegistrator.htm)|

