# CardPlatformExtensionHelper - методы

##  __Методы

[SetDigestFromNewTemplatedCard](M_Tessa_Extensions_Platform_Client_Cards_CardPlatformExtensionHelper_SetDigestFromNewTemplatedCard.htm)|
Устанавливает Digest для ещё не сохранённой карточки шаблона, для которой
файлы загружаются через
[ExternalSource](P_Tessa_Cards_CardFile_ExternalSource.htm).  
---|---  
[SetDigestInContextAsync](M_Tessa_Extensions_Platform_Client_Cards_CardPlatformExtensionHelper_SetDigestInContextAsync.htm)|
Устанавливает Digest для запроса к сервису карточек из текущего контекста
[Current](P_Tessa_UI_UIContext_Current.htm) и возвращает признак того, что
Digest был установлен (хотя бы равным null).  
  
## __См. также

#### Ссылки

[CardPlatformExtensionHelper -
](T_Tessa_Extensions_Platform_Client_Cards_CardPlatformExtensionHelper.htm)

[Tessa.Extensions.Platform.Client.Cards - пространство
имён](N_Tessa_Extensions_Platform_Client_Cards.htm)

