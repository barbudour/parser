# MethodRewriter - свойства

##  __Свойства

[VisitIntoStructuredTrivia](https://learn.microsoft.com/dotnet/api/microsoft.codeanalysis.csharp.csharpsyntaxrewriter.visitintostructuredtrivia#microsoft-
codeanalysis-csharp-csharpsyntaxrewriter-visitintostructuredtrivia)|  
(Унаследован от
[CSharpSyntaxRewriter](https://learn.microsoft.com/dotnet/api/microsoft.codeanalysis.csharp.csharpsyntaxrewriter))  
---|---  
  
##  __См. также

#### Ссылки

[MethodRewriter - ](T_Tessa_Compilation_MethodRewriter.htm)

[Tessa.Compilation - пространство имён](N_Tessa_Compilation.htm)

