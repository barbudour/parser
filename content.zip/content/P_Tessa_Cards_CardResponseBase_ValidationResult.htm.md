# CardResponseBase.ValidationResult - свойство

Объект, используемый для построения результата валидации.

## __Definition

 **Пространство имён:** [Tessa.Cards](N_Tessa_Cards.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public ValidationStorageResultBuilder ValidationResult { get; set; }

VB __Копировать

    
    
     Public Property ValidationResult As ValidationStorageResultBuilder
    	Get
    	Set

C++ __Копировать

    
    
     public:
    property ValidationStorageResultBuilder^ ValidationResult {
    	ValidationStorageResultBuilder^ get ();
    	void set (ValidationStorageResultBuilder^ value);
    }

F# __Копировать

    
    
     member ValidationResult : ValidationStorageResultBuilder with get, set

#### Значение свойства

[ValidationStorageResultBuilder](T_Tessa_Platform_Validation_ValidationStorageResultBuilder.htm)

##  __См. также

#### Ссылки

[CardResponseBase - ](T_Tessa_Cards_CardResponseBase.htm)

[Tessa.Cards - пространство имён](N_Tessa_Cards.htm)

