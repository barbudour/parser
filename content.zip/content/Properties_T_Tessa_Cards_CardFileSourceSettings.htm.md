# CardFileSourceSettings - свойства

##  __Свойства

[Empty](P_Tessa_Cards_CardFileSourceSettings_Empty.htm)|  Объект настроек,
который не содержит информации по местоположениям контента файлов.  
---|---  
  
## __См. также

#### Ссылки

[CardFileSourceSettings - ](T_Tessa_Cards_CardFileSourceSettings.htm)

[Tessa.Cards - пространство имён](N_Tessa_Cards.htm)

