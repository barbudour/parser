# KrConstants.Keys.NewCard - поле

##  __Definition

 **Пространство имён:**
[Tessa.Extensions.Default.Shared.Workflow.KrProcess](N_Tessa_Extensions_Default_Shared_Workflow_KrProcess.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public const string NewCard = "NewCard"

VB __Копировать

    
    
     Public Const NewCard As String = "NewCard"

C++ __Копировать

    
    
     public:
    literal String^ NewCard = "NewCard"

F# __Копировать

    
    
     static val mutable NewCard: string

#### Значение поля

[String](https://learn.microsoft.com/dotnet/api/system.string)

##  __См. также

#### Ссылки

[KrConstants.Keys -
](T_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrConstants_Keys.htm)

[Tessa.Extensions.Default.Shared.Workflow.KrProcess - пространство
имён](N_Tessa_Extensions_Default_Shared_Workflow_KrProcess.htm)

