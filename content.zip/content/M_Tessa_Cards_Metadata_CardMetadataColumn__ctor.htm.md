# CardMetadataColumn - конструктор

Создаёт экземпляр класса с параметрами по умолчанию.

##  __Definition

 **Пространство имён:** [Tessa.Cards.Metadata](N_Tessa_Cards_Metadata.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public CardMetadataColumn()

VB __Копировать

    
    
     Public Sub New

C++ __Копировать

    
    
     public:
    CardMetadataColumn()

F# __Копировать

    
    
     new : unit -> CardMetadataColumn

##  __См. также

#### Ссылки

[CardMetadataColumn - ](T_Tessa_Cards_Metadata_CardMetadataColumn.htm)

[CardMetadataColumn -
перегрузка](Overload_Tessa_Cards_Metadata_CardMetadataColumn__ctor.htm)

[Tessa.Cards.Metadata - пространство имён](N_Tessa_Cards_Metadata.htm)

