# DefaultCardTypes.ReportPermissionsTypeID - поле

Card type identifier for "ReportPermissions":
{65A88390-3B00-4B74-925D-B635027FEFF2}.

## __Definition

 **Пространство имён:**
[Tessa.Extensions.Default.Shared](N_Tessa_Extensions_Default_Shared.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public static readonly Guid ReportPermissionsTypeID

VB __Копировать

    
    
     Public Shared ReadOnly ReportPermissionsTypeID As Guid

C++ __Копировать

    
    
     public:
    static initonly Guid ReportPermissionsTypeID

F# __Копировать

    
    
     static val ReportPermissionsTypeID: Guid

#### Значение поля

[Guid](https://learn.microsoft.com/dotnet/api/system.guid)

##  __См. также

#### Ссылки

[DefaultCardTypes - ](T_Tessa_Extensions_Default_Shared_DefaultCardTypes.htm)

[Tessa.Extensions.Default.Shared - пространство
имён](N_Tessa_Extensions_Default_Shared.htm)

