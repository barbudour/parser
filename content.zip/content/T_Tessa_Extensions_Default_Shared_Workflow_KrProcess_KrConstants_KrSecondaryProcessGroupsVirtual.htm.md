# KrConstants.KrSecondaryProcessGroupsVirtual - класс

##  __Definition

 **Пространство имён:**
[Tessa.Extensions.Default.Shared.Workflow.KrProcess](N_Tessa_Extensions_Default_Shared_Workflow_KrProcess.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public static class KrSecondaryProcessGroupsVirtual

VB __Копировать

    
    
     Public NotInheritable Class KrSecondaryProcessGroupsVirtual

C++ __Копировать

    
    
     public ref class KrSecondaryProcessGroupsVirtual abstract sealed

F# __Копировать

    
    
     [<AbstractClassAttribute>]
    [<SealedAttribute>]
    type KrSecondaryProcessGroupsVirtual = class end

Inheritance

    [Object](https://learn.microsoft.com/dotnet/api/system.object) __ KrConstants.KrSecondaryProcessGroupsVirtual

##  __Поля

[ID](F_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrConstants_KrSecondaryProcessGroupsVirtual_ID.htm)|  
---|---  
[Name](F_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrConstants_KrSecondaryProcessGroupsVirtual_Name.htm)|  
[RowID](F_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrConstants_KrSecondaryProcessGroupsVirtual_RowID.htm)|  
[StageGroupID](F_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrConstants_KrSecondaryProcessGroupsVirtual_StageGroupID.htm)|  
[StageGroupName](F_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrConstants_KrSecondaryProcessGroupsVirtual_StageGroupName.htm)|  
  
## __См. также

#### Ссылки

[Tessa.Extensions.Default.Shared.Workflow.KrProcess - пространство
имён](N_Tessa_Extensions_Default_Shared_Workflow_KrProcess.htm)

