# KrTileInfo.IsGlobal - свойство

##  __Definition

 **Пространство имён:**
[Tessa.Extensions.Default.Shared.Workflow.KrProcess](N_Tessa_Extensions_Default_Shared_Workflow_KrProcess.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public bool IsGlobal { get; }

VB __Копировать

    
    
     Public ReadOnly Property IsGlobal As Boolean
    	Get

C++ __Копировать

    
    
     public:
    property bool IsGlobal {
    	bool get ();
    }

F# __Копировать

    
    
     member IsGlobal : bool with get

#### Значение свойства

[Boolean](https://learn.microsoft.com/dotnet/api/system.boolean)

##  __См. также

#### Ссылки

[KrTileInfo -
](T_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrTileInfo.htm)

[Tessa.Extensions.Default.Shared.Workflow.KrProcess - пространство
имён](N_Tessa_Extensions_Default_Shared_Workflow_KrProcess.htm)

