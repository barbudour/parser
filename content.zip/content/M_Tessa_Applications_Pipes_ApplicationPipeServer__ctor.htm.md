# ApplicationPipeServer - конструктор

Инициализирует новый экземпляр класса
[ApplicationPipeServer](T_Tessa_Applications_Pipes_ApplicationPipeServer.htm)

##  __Definition

 **Пространство имён:**
[Tessa.Applications.Pipes](N_Tessa_Applications_Pipes.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public ApplicationPipeServer(
    	IApplicationPipeService service,
    	IPipeMessageFactory messageFactory
    )

VB __Копировать

    
    
     Public Sub New ( 
    	service As IApplicationPipeService,
    	messageFactory As IPipeMessageFactory
    )

C++ __Копировать

    
    
     public:
    ApplicationPipeServer(
    	IApplicationPipeService^ service, 
    	IPipeMessageFactory^ messageFactory
    )

F# __Копировать

    
    
     new : 
            service : IApplicationPipeService * 
            messageFactory : IPipeMessageFactory -> ApplicationPipeServer

#### Параметры

service
[IApplicationPipeService](T_Tessa_Applications_Pipes_IApplicationPipeService.htm)

    
messageFactory
[IPipeMessageFactory](T_Tessa_Platform_Pipes_IPipeMessageFactory.htm)

    

## __См. также

#### Ссылки

[ApplicationPipeServer -
](T_Tessa_Applications_Pipes_ApplicationPipeServer.htm)

[Tessa.Applications.Pipes - пространство имён](N_Tessa_Applications_Pipes.htm)

