# CardTypeControl.SealInternal - метод

Защищает объект от изменений.

Метод может быть переопределён в классах-наследниках.

##  __Definition

 **Пространство имён:** [Tessa.Cards](N_Tessa_Cards.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     protected override void SealInternal()

VB __Копировать

    
    
     Protected Overrides Sub SealInternal

C++ __Копировать

    
    
     protected:
    virtual void SealInternal() override

F# __Копировать

    
    
     abstract SealInternal : unit -> unit 
    override SealInternal : unit -> unit 

## __См. также

#### Ссылки

[CardTypeControl - ](T_Tessa_Cards_CardTypeControl.htm)

[Tessa.Cards - пространство имён](N_Tessa_Cards.htm)

