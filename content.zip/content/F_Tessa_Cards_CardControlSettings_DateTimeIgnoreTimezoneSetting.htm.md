# CardControlSettings.DateTimeIgnoreTimezoneSetting - поле

Имя настройки, определяющей, игнорируется ли часовой пояс сотрудника.

##  __Definition

 **Пространство имён:** [Tessa.Cards](N_Tessa_Cards.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public const string DateTimeIgnoreTimezoneSetting = "IgnoreTimezone"

VB __Копировать

    
    
     Public Const DateTimeIgnoreTimezoneSetting As String = "IgnoreTimezone"

C++ __Копировать

    
    
     public:
    literal String^ DateTimeIgnoreTimezoneSetting = "IgnoreTimezone"

F# __Копировать

    
    
     static val mutable DateTimeIgnoreTimezoneSetting: string

#### Значение поля

[String](https://learn.microsoft.com/dotnet/api/system.string)

##  __См. также

#### Ссылки

[CardControlSettings - ](T_Tessa_Cards_CardControlSettings.htm)

[Tessa.Cards - пространство имён](N_Tessa_Cards.htm)

