# DefaultCompletionOptions.RejectApproval - поле

Вариант завершения "Отозвать согласование".

## __Definition

 **Пространство имён:**
[Tessa.Extensions.Default.Shared](N_Tessa_Extensions_Default_Shared.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public static readonly Guid RejectApproval

VB __Копировать

    
    
     Public Shared ReadOnly RejectApproval As Guid

C++ __Копировать

    
    
     public:
    static initonly Guid RejectApproval

F# __Копировать

    
    
     static val RejectApproval: Guid

#### Значение поля

[Guid](https://learn.microsoft.com/dotnet/api/system.guid)

##  __См. также

#### Ссылки

[DefaultCompletionOptions -
](T_Tessa_Extensions_Default_Shared_DefaultCompletionOptions.htm)

[Tessa.Extensions.Default.Shared - пространство
имён](N_Tessa_Extensions_Default_Shared.htm)

