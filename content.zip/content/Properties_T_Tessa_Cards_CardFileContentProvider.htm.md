# CardFileContentProvider - свойства

##  __Свойства

[FileID](P_Tessa_Cards_CardFileContentProvider_FileID.htm)| Идентификатор
файла.  
---|---  
[Size](P_Tessa_Cards_CardFileContentProvider_Size.htm)| Размер файла в байтах.  
  
##  __См. также

#### Ссылки

[CardFileContentProvider - ](T_Tessa_Cards_CardFileContentProvider.htm)

[Tessa.Cards - пространство имён](N_Tessa_Cards.htm)

