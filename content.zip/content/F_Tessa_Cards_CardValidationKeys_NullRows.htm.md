# CardValidationKeys.NullRows - поле

Валидатор сообщил, что коллекционная или древовидная секция карточки не
содержит строк.

## __Definition

 **Пространство имён:** [Tessa.Cards](N_Tessa_Cards.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public static readonly ValidationKey NullRows

VB __Копировать

    
    
     Public Shared ReadOnly NullRows As ValidationKey

C++ __Копировать

    
    
     public:
    static initonly ValidationKey^ NullRows

F# __Копировать

    
    
     static val NullRows: ValidationKey

#### Значение поля

[ValidationKey](T_Tessa_Platform_Validation_ValidationKey.htm)

##  __См. также

#### Ссылки

[CardValidationKeys - ](T_Tessa_Cards_CardValidationKeys.htm)

[Tessa.Cards - пространство имён](N_Tessa_Cards.htm)

