# ApplicationsWebProxy - конструктор

Создаёт экземпляр класса с параметрами по умолчанию.

##  __Definition

 **Пространство имён:**
[Tessa.Applications.Services.TessaServer](N_Tessa_Applications_Services_TessaServer.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public ApplicationsWebProxy()

VB __Копировать

    
    
     Public Sub New

C++ __Копировать

    
    
     public:
    ApplicationsWebProxy()

F# __Копировать

    
    
     new : unit -> ApplicationsWebProxy

##  __См. также

#### Ссылки

[ApplicationsWebProxy -
](T_Tessa_Applications_Services_TessaServer_ApplicationsWebProxy.htm)

[Tessa.Applications.Services.TessaServer - пространство
имён](N_Tessa_Applications_Services_TessaServer.htm)

