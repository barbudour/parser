# IMessageHandler - интерфейс

##  __Definition

 **Пространство имён:**
[Tessa.Extensions.Default.Server.Notices](N_Tessa_Extensions_Default_Server_Notices.htm)  
 **Сборка:** Tessa.Extensions.Default.Server (в
Tessa.Extensions.Default.Server.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public interface IMessageHandler

VB __Копировать

    
    
     Public Interface IMessageHandler

C++ __Копировать

    
    
     public interface class IMessageHandler

F# __Копировать

    
    
     type IMessageHandler = interface end

##  __Методы

[HandleAsync](M_Tessa_Extensions_Default_Server_Notices_IMessageHandler_HandleAsync.htm)|  
---|---  
[TryParseAsync](M_Tessa_Extensions_Default_Server_Notices_IMessageHandler_TryParseAsync.htm)|  
  
## __См. также

#### Ссылки

[Tessa.Extensions.Default.Server.Notices - пространство
имён](N_Tessa_Extensions_Default_Server_Notices.htm)

