# CardGetFileVersionsResponse - конструктор

##  __Список перегрузок

[CardGetFileVersionsResponse()](M_Tessa_Cards_CardGetFileVersionsResponse__ctor.htm)|
Создаёт экземпляр класса и пустое хранилище Dictionary<string, object>,
декоратором для которого является создаваемый объект.  
---|---  
[CardGetFileVersionsResponse(Dictionary<String,
Object>)](M_Tessa_Cards_CardGetFileVersionsResponse__ctor_1.htm)| Создаёт
экземпляр класса с указанием хранилища, декоратором для которого является
создаваемый объект.  
[CardGetFileVersionsResponse(IStorageObjectProvider)](M_Tessa_Cards_CardGetFileVersionsResponse__ctor_2.htm)|
Создаёт экземпляр класса с указанием объекта, предоставляющего доступ к
хранилищу, декоратором для которого является создаваемый объект.  
  
## __См. также

#### Ссылки

[CardGetFileVersionsResponse -
](T_Tessa_Cards_CardGetFileVersionsResponse.htm)

[Tessa.Cards - пространство имён](N_Tessa_Cards.htm)

