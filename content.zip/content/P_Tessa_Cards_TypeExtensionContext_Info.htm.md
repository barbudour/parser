# TypeExtensionContext.Info - свойство

Дополнительная информация, связанная с контекстом.

##  __Definition

 **Пространство имён:** [Tessa.Cards](N_Tessa_Cards.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public ISerializableObject Info { get; }

VB __Копировать

    
    
     Public ReadOnly Property Info As ISerializableObject
    	Get

C++ __Копировать

    
    
     public:
    virtual property ISerializableObject^ Info {
    	ISerializableObject^ get () sealed;
    }

F# __Копировать

    
    
     abstract Info : ISerializableObject with get
    override Info : ISerializableObject with get

#### Значение свойства

[ISerializableObject](T_Tessa_Platform_Storage_ISerializableObject.htm)

#### Реализации

[ITypeExtensionContext.Info](P_Tessa_Cards_ITypeExtensionContext_Info.htm)  

##  __См. также

#### Ссылки

[TypeExtensionContext - ](T_Tessa_Cards_TypeExtensionContext.htm)

[Tessa.Cards - пространство имён](N_Tessa_Cards.htm)

