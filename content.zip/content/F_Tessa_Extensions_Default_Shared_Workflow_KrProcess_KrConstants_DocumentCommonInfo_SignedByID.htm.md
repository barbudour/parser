# KrConstants.DocumentCommonInfo.SignedByID - поле

##  __Definition

 **Пространство имён:**
[Tessa.Extensions.Default.Shared.Workflow.KrProcess](N_Tessa_Extensions_Default_Shared_Workflow_KrProcess.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public const string SignedByID = "SignedByID"

VB __Копировать

    
    
     Public Const SignedByID As String = "SignedByID"

C++ __Копировать

    
    
     public:
    literal String^ SignedByID = "SignedByID"

F# __Копировать

    
    
     static val mutable SignedByID: string

#### Значение поля

[String](https://learn.microsoft.com/dotnet/api/system.string)

##  __См. также

#### Ссылки

[KrConstants.DocumentCommonInfo -
](T_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrConstants_DocumentCommonInfo.htm)

[Tessa.Extensions.Default.Shared.Workflow.KrProcess - пространство
имён](N_Tessa_Extensions_Default_Shared_Workflow_KrProcess.htm)

