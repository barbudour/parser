# KrProcessClientLauncher - конструктор

Инициализирует новый экземпляр класса
[KrProcessClientLauncher](T_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrProcessClientLauncher.htm).

## __Definition

 **Пространство имён:**
[Tessa.Extensions.Default.Shared.Workflow.KrProcess](N_Tessa_Extensions_Default_Shared_Workflow_KrProcess.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public KrProcessClientLauncher(
    	ICardRepository cardRepository
    )

VB __Копировать

    
    
     Public Sub New ( 
    	cardRepository As ICardRepository
    )

C++ __Копировать

    
    
     public:
    KrProcessClientLauncher(
    	ICardRepository^ cardRepository
    )

F# __Копировать

    
    
     new : 
            cardRepository : ICardRepository -> KrProcessClientLauncher

#### Параметры

cardRepository [ICardRepository](T_Tessa_Cards_ICardRepository.htm)

    Репозиторий для управления карточками.

##  __См. также

#### Ссылки

[KrProcessClientLauncher -
](T_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrProcessClientLauncher.htm)

[Tessa.Extensions.Default.Shared.Workflow.KrProcess - пространство
имён](N_Tessa_Extensions_Default_Shared_Workflow_KrProcess.htm)

