# WorkflowConstants.KrApprovalActionNotificationRolesVirtual - конструктор

Инициализирует новый экземпляр класса
[WorkflowConstants.KrApprovalActionNotificationRolesVirtual](T_Tessa_Extensions_Default_Shared_Workflow_WorkflowEngine_WorkflowConstants_KrApprovalActionNotificationRolesVirtual.htm)

##  __Definition

 **Пространство имён:**
[Tessa.Extensions.Default.Shared.Workflow.WorkflowEngine](N_Tessa_Extensions_Default_Shared_Workflow_WorkflowEngine.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     protected KrApprovalActionNotificationRolesVirtual()

VB __Копировать

    
    
     Protected Sub New

C++ __Копировать

    
    
     protected:
    KrApprovalActionNotificationRolesVirtual()

F# __Копировать

    
    
     new : unit -> KrApprovalActionNotificationRolesVirtual

##  __См. также

#### Ссылки

[WorkflowConstants.KrApprovalActionNotificationRolesVirtual -
](T_Tessa_Extensions_Default_Shared_Workflow_WorkflowEngine_WorkflowConstants_KrApprovalActionNotificationRolesVirtual.htm)

[Tessa.Extensions.Default.Shared.Workflow.WorkflowEngine - пространство
имён](N_Tessa_Extensions_Default_Shared_Workflow_WorkflowEngine.htm)

