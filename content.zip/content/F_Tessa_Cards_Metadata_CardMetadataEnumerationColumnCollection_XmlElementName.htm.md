# CardMetadataEnumerationColumnCollection.XmlElementName - поле

Имя XML-элемента.

## __Definition

 **Пространство имён:** [Tessa.Cards.Metadata](N_Tessa_Cards_Metadata.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public const string XmlElementName = "columns"

VB __Копировать

    
    
     Public Const XmlElementName As String = "columns"

C++ __Копировать

    
    
     public:
    literal String^ XmlElementName = "columns"

F# __Копировать

    
    
     static val mutable XmlElementName: string

#### Значение поля

[String](https://learn.microsoft.com/dotnet/api/system.string)

##  __См. также

#### Ссылки

[CardMetadataEnumerationColumnCollection -
](T_Tessa_Cards_Metadata_CardMetadataEnumerationColumnCollection.htm)

[Tessa.Cards.Metadata - пространство имён](N_Tessa_Cards_Metadata.htm)

