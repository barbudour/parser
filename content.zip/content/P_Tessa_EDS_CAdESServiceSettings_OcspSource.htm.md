# CAdESServiceSettings.OcspSource - свойство

##  __Definition

 **Пространство имён:** [Tessa.EDS](N_Tessa_EDS.htm)  
 **Сборка:** Tessa.Server (в Tessa.Server.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public string OcspSource { get; }

VB __Копировать

    
    
     Public ReadOnly Property OcspSource As String
    	Get

C++ __Копировать

    
    
     public:
    virtual property String^ OcspSource {
    	String^ get () sealed;
    }

F# __Копировать

    
    
     abstract OcspSource : string with get
    override OcspSource : string with get

#### Значение свойства

[String](https://learn.microsoft.com/dotnet/api/system.string)

#### Реализации

IOcspServiceSettings.OcspSource  

##  __См. также

#### Ссылки

[CAdESServiceSettings - ](T_Tessa_EDS_CAdESServiceSettings.htm)

[Tessa.EDS - пространство имён](N_Tessa_EDS.htm)

