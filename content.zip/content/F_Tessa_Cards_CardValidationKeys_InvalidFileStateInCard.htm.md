# CardValidationKeys.InvalidFileStateInCard - поле

Указанный файл присутствует в потоке карточки, но имеет неверное состояние в
карточке.

## __Definition

 **Пространство имён:** [Tessa.Cards](N_Tessa_Cards.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public static readonly ValidationKey InvalidFileStateInCard

VB __Копировать

    
    
     Public Shared ReadOnly InvalidFileStateInCard As ValidationKey

C++ __Копировать

    
    
     public:
    static initonly ValidationKey^ InvalidFileStateInCard

F# __Копировать

    
    
     static val InvalidFileStateInCard: ValidationKey

#### Значение поля

[ValidationKey](T_Tessa_Platform_Validation_ValidationKey.htm)

##  __См. также

#### Ссылки

[CardValidationKeys - ](T_Tessa_Cards_CardValidationKeys.htm)

[Tessa.Cards - пространство имён](N_Tessa_Cards.htm)

