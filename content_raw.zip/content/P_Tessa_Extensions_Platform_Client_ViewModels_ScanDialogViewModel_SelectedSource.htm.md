# ScanDialogViewModel.SelectedSource - свойство

Текущий выбранный сканер.

## __Definition

 **Пространство имён:**
[Tessa.Extensions.Platform.Client.ViewModels](N_Tessa_Extensions_Platform_Client_ViewModels.htm)  
 **Сборка:** Tessa.UI (в Tessa.UI.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public IScanSource SelectedSource { get; set; }

VB __Копировать

    
    
     Public Property SelectedSource As IScanSource
    	Get
    	Set

C++ __Копировать

    
    
     public:
    property IScanSource^ SelectedSource {
    	IScanSource^ get ();
    	void set (IScanSource^ value);
    }

F# __Копировать

    
    
     member SelectedSource : IScanSource with get, set

#### Значение свойства

[IScanSource](T_Tessa_Host_IScanSource.htm)

##  __См. также

#### Ссылки

[ScanDialogViewModel -
](T_Tessa_Extensions_Platform_Client_ViewModels_ScanDialogViewModel.htm)

[Tessa.Extensions.Platform.Client.ViewModels - пространство
имён](N_Tessa_Extensions_Platform_Client_ViewModels.htm)

