# ScanDialogViewModel - конструктор

Инициализирует новый экземпляр класса
[ScanDialogViewModel](T_Tessa_Extensions_Platform_Client_ViewModels_ScanDialogViewModel.htm)

##  __Definition

 **Пространство имён:**
[Tessa.Extensions.Platform.Client.ViewModels](N_Tessa_Extensions_Platform_Client_ViewModels.htm)  
 **Сборка:** Tessa.UI (в Tessa.UI.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public ScanDialogViewModel(
    	ScanFileDialogSettings settings
    )

VB __Копировать

    
    
     Public Sub New ( 
    	settings As ScanFileDialogSettings
    )

C++ __Копировать

    
    
     public:
    ScanDialogViewModel(
    	ScanFileDialogSettings^ settings
    )

F# __Копировать

    
    
     new : 
            settings : ScanFileDialogSettings -> ScanDialogViewModel

#### Параметры

settings
[ScanFileDialogSettings](T_Tessa_Extensions_Platform_Client_Scanning_ScanFileDialogSettings.htm)

    

## __См. также

#### Ссылки

[ScanDialogViewModel -
](T_Tessa_Extensions_Platform_Client_ViewModels_ScanDialogViewModel.htm)

[Tessa.Extensions.Platform.Client.ViewModels - пространство
имён](N_Tessa_Extensions_Platform_Client_ViewModels.htm)

