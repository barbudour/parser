# KrConstants.KrAcquaintanceSettingsVirtual.NotificationID - поле

##  __Definition

 **Пространство имён:**
[Tessa.Extensions.Default.Shared.Workflow.KrProcess](N_Tessa_Extensions_Default_Shared_Workflow_KrProcess.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public static readonly string NotificationID

VB __Копировать

    
    
     Public Shared ReadOnly NotificationID As String

C++ __Копировать

    
    
     public:
    static initonly String^ NotificationID

F# __Копировать

    
    
     static val NotificationID: string

#### Значение поля

[String](https://learn.microsoft.com/dotnet/api/system.string)

##  __См. также

#### Ссылки

[KrConstants.KrAcquaintanceSettingsVirtual -
](T_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrConstants_KrAcquaintanceSettingsVirtual.htm)

[Tessa.Extensions.Default.Shared.Workflow.KrProcess - пространство
имён](N_Tessa_Extensions_Default_Shared_Workflow_KrProcess.htm)

