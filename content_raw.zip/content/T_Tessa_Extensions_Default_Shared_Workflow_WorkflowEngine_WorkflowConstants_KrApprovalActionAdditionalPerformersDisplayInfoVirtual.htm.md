# WorkflowConstants.KrApprovalActionAdditionalPerformersDisplayInfoVirtual -
класс

##  __Definition

 **Пространство имён:**
[Tessa.Extensions.Default.Shared.Workflow.WorkflowEngine](N_Tessa_Extensions_Default_Shared_Workflow_WorkflowEngine.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public static class KrApprovalActionAdditionalPerformersDisplayInfoVirtual

VB __Копировать

    
    
     Public NotInheritable Class KrApprovalActionAdditionalPerformersDisplayInfoVirtual

C++ __Копировать

    
    
     public ref class KrApprovalActionAdditionalPerformersDisplayInfoVirtual abstract sealed

F# __Копировать

    
    
     [<AbstractClassAttribute>]
    [<SealedAttribute>]
    type KrApprovalActionAdditionalPerformersDisplayInfoVirtual = class end

Inheritance

    [Object](https://learn.microsoft.com/dotnet/api/system.object) __ WorkflowConstants.KrApprovalActionAdditionalPerformersDisplayInfoVirtual

##  __Поля

[IsResponsible](F_Tessa_Extensions_Default_Shared_Workflow_WorkflowEngine_WorkflowConstants_KrApprovalActionAdditionalPerformersDisplayInfoVirtual_IsResponsible.htm)|  
---|---  
[MainApproverRowID](F_Tessa_Extensions_Default_Shared_Workflow_WorkflowEngine_WorkflowConstants_KrApprovalActionAdditionalPerformersDisplayInfoVirtual_MainApproverRowID.htm)|  
[Order](F_Tessa_Extensions_Default_Shared_Workflow_WorkflowEngine_WorkflowConstants_KrApprovalActionAdditionalPerformersDisplayInfoVirtual_Order.htm)|  
[RoleID](F_Tessa_Extensions_Default_Shared_Workflow_WorkflowEngine_WorkflowConstants_KrApprovalActionAdditionalPerformersDisplayInfoVirtual_RoleID.htm)|  
[RoleName](F_Tessa_Extensions_Default_Shared_Workflow_WorkflowEngine_WorkflowConstants_KrApprovalActionAdditionalPerformersDisplayInfoVirtual_RoleName.htm)|  
[SectionName](F_Tessa_Extensions_Default_Shared_Workflow_WorkflowEngine_WorkflowConstants_KrApprovalActionAdditionalPerformersDisplayInfoVirtual_SectionName.htm)|  
  
## __См. также

#### Ссылки

[Tessa.Extensions.Default.Shared.Workflow.WorkflowEngine - пространство
имён](N_Tessa_Extensions_Default_Shared_Workflow_WorkflowEngine.htm)

