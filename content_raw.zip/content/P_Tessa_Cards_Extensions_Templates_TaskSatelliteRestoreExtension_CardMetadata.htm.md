# TaskSatelliteRestoreExtension.CardMetadata - свойство

Метаданные по типам карточек.

## __Definition

 **Пространство имён:**
[Tessa.Cards.Extensions.Templates](N_Tessa_Cards_Extensions_Templates.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public ICardMetadata CardMetadata { get; }

VB __Копировать

    
    
     Public ReadOnly Property CardMetadata As ICardMetadata
    	Get

C++ __Копировать

    
    
     public:
    property ICardMetadata^ CardMetadata {
    	ICardMetadata^ get ();
    }

F# __Копировать

    
    
     member CardMetadata : ICardMetadata with get

#### Значение свойства

[ICardMetadata](T_Tessa_Cards_ICardMetadata.htm)

##  __См. также

#### Ссылки

[TaskSatelliteRestoreExtension -
](T_Tessa_Cards_Extensions_Templates_TaskSatelliteRestoreExtension.htm)

[Tessa.Cards.Extensions.Templates - пространство
имён](N_Tessa_Cards_Extensions_Templates.htm)

