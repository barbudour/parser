# AttachmentStoreMode - перечисление

Режим сохранения вложения.

## __Definition

 **Пространство имён:** [Tessa.Forums.Models](N_Tessa_Forums_Models.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public enum AttachmentStoreMode

VB __Копировать

    
    
     Public Enumeration AttachmentStoreMode

C++ __Копировать

    
    
     public enum class AttachmentStoreMode

F# __Копировать

    
    
     type AttachmentStoreMode

##  __Члены

Insert| 0|  Вложение добавляется.  
---|---|---  
Delete| 1|  Вложение удаляется.  
NotChanged| 2|  Вложение не изменяется.  
Changed| 3|  Вложение изменяется.  
  
## __См. также

#### Ссылки

[Tessa.Forums.Models - пространство имён](N_Tessa_Forums_Models.htm)

