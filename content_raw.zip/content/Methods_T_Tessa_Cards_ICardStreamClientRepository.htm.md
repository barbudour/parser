# ICardStreamClientRepository - методы

##  __Методы

[GetFileContentAsync](M_Tessa_Cards_ICardStreamClientRepository_GetFileContentAsync.htm)|
Получает контент версии файла.  
---|---  
[StoreAsync](M_Tessa_Cards_ICardStreamClientRepository_StoreAsync.htm)|
Сохраняет карточку с контентом файлов, которые упаковываются в поток карточки
перед отправкой на сервер.  
  
##  __Методы расширения

[GenerateExportAsync](M_Tessa_Cards_CardExtensions_GenerateExportAsync.htm)|
Создаёт файл по заданному шаблону и возвращает контент созданного файла и
ответ на запрос на создание.  
(Определяется [CardExtensions](T_Tessa_Cards_CardExtensions.htm))  
---|---  
[GenerateFileFromTemplateAsync](M_Tessa_Cards_CardExtensions_GenerateFileFromTemplateAsync.htm)|
Создаёт файл по заданному шаблону и возвращает контент созданного файла и
ответ на запрос на создание.  
(Определяется [CardExtensions](T_Tessa_Cards_CardExtensions.htm))  
  
##  __См. также

#### Ссылки

[ICardStreamClientRepository -
](T_Tessa_Cards_ICardStreamClientRepository.htm)

[Tessa.Cards - пространство имён](N_Tessa_Cards.htm)

