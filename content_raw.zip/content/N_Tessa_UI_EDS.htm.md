# Tessa.UI.EDS - пространство имён

API для ЭЦП.

##  __Классы

[EDSCertificateProvider](T_Tessa_UI_EDS_EDSCertificateProvider.htm)|  Объект,
используемый для выбора сертификатов.  
---|---  
[EdsUIExtensions](T_Tessa_UI_EDS_EdsUIExtensions.htm)|  Методы-расширения для
пространства имён Tessa.UI.EDS.

