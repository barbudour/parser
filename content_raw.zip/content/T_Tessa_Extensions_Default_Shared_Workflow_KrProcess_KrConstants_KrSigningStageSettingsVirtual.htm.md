# KrConstants.KrSigningStageSettingsVirtual - класс

##  __Definition

 **Пространство имён:**
[Tessa.Extensions.Default.Shared.Workflow.KrProcess](N_Tessa_Extensions_Default_Shared_Workflow_KrProcess.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public static class KrSigningStageSettingsVirtual

VB __Копировать

    
    
     Public NotInheritable Class KrSigningStageSettingsVirtual

C++ __Копировать

    
    
     public ref class KrSigningStageSettingsVirtual abstract sealed

F# __Копировать

    
    
     [<AbstractClassAttribute>]
    [<SealedAttribute>]
    type KrSigningStageSettingsVirtual = class end

Inheritance

    [Object](https://learn.microsoft.com/dotnet/api/system.object) __ KrConstants.KrSigningStageSettingsVirtual

##  __Поля

[AllowAdditionalApproval](F_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrConstants_KrSigningStageSettingsVirtual_AllowAdditionalApproval.htm)|  
---|---  
[CanEditCard](F_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrConstants_KrSigningStageSettingsVirtual_CanEditCard.htm)|  
[CanEditFiles](F_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrConstants_KrSigningStageSettingsVirtual_CanEditFiles.htm)|  
[ChangeStateOnEnd](F_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrConstants_KrSigningStageSettingsVirtual_ChangeStateOnEnd.htm)|  
[ChangeStateOnStart](F_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrConstants_KrSigningStageSettingsVirtual_ChangeStateOnStart.htm)|  
[Comment](F_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrConstants_KrSigningStageSettingsVirtual_Comment.htm)|  
[IsParallel](F_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrConstants_KrSigningStageSettingsVirtual_IsParallel.htm)|  
[Name](F_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrConstants_KrSigningStageSettingsVirtual_Name.htm)|  
[NotReturnEdit](F_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrConstants_KrSigningStageSettingsVirtual_NotReturnEdit.htm)|  
[ReturnToAuthor](F_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrConstants_KrSigningStageSettingsVirtual_ReturnToAuthor.htm)|  
[ReturnWhenDeclined](F_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrConstants_KrSigningStageSettingsVirtual_ReturnWhenDeclined.htm)|  
  
## __См. также

#### Ссылки

[Tessa.Extensions.Default.Shared.Workflow.KrProcess - пространство
имён](N_Tessa_Extensions_Default_Shared_Workflow_KrProcess.htm)

