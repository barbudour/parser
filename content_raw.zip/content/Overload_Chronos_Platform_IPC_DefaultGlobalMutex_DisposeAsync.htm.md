# DefaultGlobalMutex.DisposeAsync - метод

##  __Список перегрузок

[DisposeAsync()](M_Chronos_Platform_IPC_GlobalMutexBase_DisposeAsync.htm)|
Освобождает ресурсы, занимаемые объектом.  
---|---  
[DisposeAsync(Boolean)](M_Chronos_Platform_IPC_DefaultGlobalMutex_DisposeAsync.htm)|
Освобождает ресурсы, занимаемые объектом.  
  
##  __См. также

#### Ссылки

[DefaultGlobalMutex - ](T_Chronos_Platform_IPC_DefaultGlobalMutex.htm)

[Chronos.Platform.IPC - пространство имён](N_Chronos_Platform_IPC.htm)

