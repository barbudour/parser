# LdapProvider - свойства

##  __Свойства

[Settings](P_Tessa_Extensions_Platform_Server_AdSync_LdapProvider_Settings.htm)|  
---|---  
  
## __См. также

#### Ссылки

[LdapProvider - ](T_Tessa_Extensions_Platform_Server_AdSync_LdapProvider.htm)

[Tessa.Extensions.Platform.Server.AdSync - пространство
имён](N_Tessa_Extensions_Platform_Server_AdSync.htm)

