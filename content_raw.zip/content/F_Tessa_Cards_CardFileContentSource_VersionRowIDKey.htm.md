# CardFileContentSource.VersionRowIDKey - поле

##  __Definition

 **Пространство имён:** [Tessa.Cards](N_Tessa_Cards.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public const string VersionRowIDKey = "VersionRowID"

VB __Копировать

    
    
     Public Const VersionRowIDKey As String = "VersionRowID"

C++ __Копировать

    
    
     public:
    literal String^ VersionRowIDKey = "VersionRowID"

F# __Копировать

    
    
     static val mutable VersionRowIDKey: string

#### Значение поля

[String](https://learn.microsoft.com/dotnet/api/system.string)

##  __См. также

#### Ссылки

[CardFileContentSource - ](T_Tessa_Cards_CardFileContentSource.htm)

[Tessa.Cards - пространство имён](N_Tessa_Cards.htm)

