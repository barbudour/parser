# UpdatePackageWithOldFileIdBuilderContext.ValidationResultBuilder - свойство

Gets Построитель результатов валидации

## __Definition

 **Пространство имён:**
[Tessa.Applications.Package](N_Tessa_Applications_Package.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public IValidationResultBuilder ValidationResultBuilder { get; }

VB __Копировать

    
    
     Public ReadOnly Property ValidationResultBuilder As IValidationResultBuilder
    	Get

C++ __Копировать

    
    
     public:
    virtual property IValidationResultBuilder^ ValidationResultBuilder {
    	IValidationResultBuilder^ get () sealed;
    }

F# __Копировать

    
    
     abstract ValidationResultBuilder : IValidationResultBuilder with get
    override ValidationResultBuilder : IValidationResultBuilder with get

#### Значение свойства

[IValidationResultBuilder](T_Tessa_Platform_Validation_IValidationResultBuilder.htm)

#### Реализации

[IApplicationPackageBuilderContext.ValidationResultBuilder](P_Tessa_Applications_Package_IApplicationPackageBuilderContext_ValidationResultBuilder.htm)  

##  __См. также

#### Ссылки

[UpdatePackageWithOldFileIdBuilderContext -
](T_Tessa_Applications_Package_UpdatePackageWithOldFileIdBuilderContext.htm)

[Tessa.Applications.Package - пространство
имён](N_Tessa_Applications_Package.htm)

