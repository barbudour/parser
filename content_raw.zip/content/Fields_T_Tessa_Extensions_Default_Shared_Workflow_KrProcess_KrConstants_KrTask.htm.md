# KrTask - поля

##  __Поля

[Comment](F_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrConstants_KrTask_Comment.htm)|  
---|---  
[DelegateID](F_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrConstants_KrTask_DelegateID.htm)|  
[DelegateName](F_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrConstants_KrTask_DelegateName.htm)|  
[Name](F_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrConstants_KrTask_Name.htm)|  
  
## __См. также

#### Ссылки

[KrConstants.KrTask -
](T_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrConstants_KrTask.htm)

[Tessa.Extensions.Default.Shared.Workflow.KrProcess - пространство
имён](N_Tessa_Extensions_Default_Shared_Workflow_KrProcess.htm)

