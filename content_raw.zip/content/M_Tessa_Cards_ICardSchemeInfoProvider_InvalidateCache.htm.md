# ICardSchemeInfoProvider.InvalidateCache - метод

Сбрасывает кэш в текущем объекте.

## __Definition

 **Пространство имён:** [Tessa.Cards](N_Tessa_Cards.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     void InvalidateCache()

VB __Копировать

    
    
     Sub InvalidateCache

C++ __Копировать

    
    
     void InvalidateCache()

F# __Копировать

    
    
     abstract InvalidateCache : unit -> unit 

## __См. также

#### Ссылки

[ICardSchemeInfoProvider - ](T_Tessa_Cards_ICardSchemeInfoProvider.htm)

[Tessa.Cards - пространство имён](N_Tessa_Cards.htm)

