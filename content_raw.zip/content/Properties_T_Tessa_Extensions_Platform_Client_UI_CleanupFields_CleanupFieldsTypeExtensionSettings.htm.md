# CleanupFieldsTypeExtensionSettings - свойства

##  __Свойства

[SourceFieldsNamesList](P_Tessa_Extensions_Platform_Client_UI_CleanupFields_CleanupFieldsTypeExtensionSettings_SourceFieldsNamesList.htm)|  
---|---  
[SourceSectionName](P_Tessa_Extensions_Platform_Client_UI_CleanupFields_CleanupFieldsTypeExtensionSettings_SourceSectionName.htm)|  
[TargetFieldsNamesList](P_Tessa_Extensions_Platform_Client_UI_CleanupFields_CleanupFieldsTypeExtensionSettings_TargetFieldsNamesList.htm)|  
[TargetSectionName](P_Tessa_Extensions_Platform_Client_UI_CleanupFields_CleanupFieldsTypeExtensionSettings_TargetSectionName.htm)|  
  
## __См. также

#### Ссылки

[CleanupFieldsTypeExtensionSettings -
](T_Tessa_Extensions_Platform_Client_UI_CleanupFields_CleanupFieldsTypeExtensionSettings.htm)

[Tessa.Extensions.Platform.Client.UI.CleanupFields - пространство
имён](N_Tessa_Extensions_Platform_Client_UI_CleanupFields.htm)

