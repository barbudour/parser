# IMergeMetadataTier - свойства

##  __Свойства

[Nodes](P_Tessa_SmartMerge_IMergeMetadataTier_Nodes.htm)|  Узлы метаданных
слияния, содержащиеся на текущем уровне метаданных слияния  
---|---  
  
## __См. также

#### Ссылки

[IMergeMetadataTier - ](T_Tessa_SmartMerge_IMergeMetadataTier.htm)

[Tessa.SmartMerge - пространство имён](N_Tessa_SmartMerge.htm)

