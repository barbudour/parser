# ICompilationContext - свойства

##  __Свойства

[AssemblyID](P_Tessa_Compilation_ICompilationContext_AssemblyID.htm)|
Уникальный идентификатор сеанса сборки  
---|---  
[DefaultUsings](P_Tessa_Compilation_ICompilationContext_DefaultUsings.htm)|
Пространства имен, добавляемые к каждому исходнику в Sources  
[GenerateFile](P_Tessa_Compilation_ICompilationContext_GenerateFile.htm)|  
[IgnoreWarnings](P_Tessa_Compilation_ICompilationContext_IgnoreWarnings.htm)|  
[References](P_Tessa_Compilation_ICompilationContext_References.htm)|  Внешние
зависимости. Необходимо указывать имена .dll файлов Пример: Tessa.dll,
System.dll и тд  
[Sources](P_Tessa_Compilation_ICompilationContext_Sources.htm)|  Исходные коды  
  
## __См. также

#### Ссылки

[ICompilationContext - ](T_Tessa_Compilation_ICompilationContext.htm)

[Tessa.Compilation - пространство имён](N_Tessa_Compilation.htm)

