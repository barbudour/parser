# Tessa.Extensions.Default.Console.ImportCards - пространство имён

## __Классы

[Command](T_Tessa_Extensions_Default_Console_ImportCards_Command.htm)|  
---|---  
[CommandRegistrator](T_Tessa_Extensions_Default_Console_ImportCards_CommandRegistrator.htm)|  
[Operation](T_Tessa_Extensions_Default_Console_ImportCards_Operation.htm)|  
[OperationContext](T_Tessa_Extensions_Default_Console_ImportCards_OperationContext.htm)|  
[OperationRegistrator](T_Tessa_Extensions_Default_Console_ImportCards_OperationRegistrator.htm)|

