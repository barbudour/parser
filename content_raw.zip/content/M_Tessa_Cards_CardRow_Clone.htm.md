# CardRow.Clone - метод

Выполняет глубокое клонирование хранилища объекта и возвращает созданный
строго типизированный декоратор для хранилища.

## __Definition

 **Пространство имён:** [Tessa.Cards](N_Tessa_Cards.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public CardRow Clone()

VB __Копировать

    
    
     Public Function Clone As CardRow

C++ __Копировать

    
    
     public:
    CardRow^ Clone()

F# __Копировать

    
    
     member Clone : unit -> CardRow 

#### Возвращаемое значение

[CardRow](T_Tessa_Cards_CardRow.htm)  
Созданный строго типизированный декоратор для хранилища, полученного глубоким
клонированием текущего хранилища.

## __См. также

#### Ссылки

[CardRow - ](T_Tessa_Cards_CardRow.htm)

[Tessa.Cards - пространство имён](N_Tessa_Cards.htm)

