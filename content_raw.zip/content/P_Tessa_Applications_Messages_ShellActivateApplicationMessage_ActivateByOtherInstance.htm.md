# ShellActivateApplicationMessage.ActivateByOtherInstance - свойство

Gets or sets a value indicating whether Признак активации другим запущенным
экземпляром приложения

## __Definition

 **Пространство имён:**
[Tessa.Applications.Messages](N_Tessa_Applications_Messages.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17

C# __Копировать

    
    
    [DataMemberAttribute]
    public bool ActivateByOtherInstance { get; set; }

VB __Копировать

    
    
    <DataMemberAttribute>
    Public Property ActivateByOtherInstance As Boolean
    	Get
    	Set

C++ __Копировать

    
    
     public:
    [DataMemberAttribute]
    property bool ActivateByOtherInstance {
    	bool get ();
    	void set (bool value);
    }

F# __Копировать

    
    
     [<DataMemberAttribute>]
    member ActivateByOtherInstance : bool with get, set

#### Значение свойства

[Boolean](https://learn.microsoft.com/dotnet/api/system.boolean)

##  __См. также

#### Ссылки

[ShellActivateApplicationMessage -
](T_Tessa_Applications_Messages_ShellActivateApplicationMessage.htm)

[Tessa.Applications.Messages - пространство
имён](N_Tessa_Applications_Messages.htm)

