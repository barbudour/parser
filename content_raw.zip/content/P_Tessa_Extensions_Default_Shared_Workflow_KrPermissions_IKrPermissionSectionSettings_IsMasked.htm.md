# IKrPermissionSectionSettings.IsMasked - свойство

##  __Definition

 **Пространство имён:**
[Tessa.Extensions.Default.Shared.Workflow.KrPermissions](N_Tessa_Extensions_Default_Shared_Workflow_KrPermissions.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     bool IsMasked { get; set; }

VB __Копировать

    
    
     Property IsMasked As Boolean
    	Get
    	Set

C++ __Копировать

    
    
    property bool IsMasked {
    	bool get ();
    	void set (bool value);
    }

F# __Копировать

    
    
     abstract IsMasked : bool with get, set

#### Значение свойства

[Boolean](https://learn.microsoft.com/dotnet/api/system.boolean)

##  __См. также

#### Ссылки

[IKrPermissionSectionSettings -
](T_Tessa_Extensions_Default_Shared_Workflow_KrPermissions_IKrPermissionSectionSettings.htm)

[Tessa.Extensions.Default.Shared.Workflow.KrPermissions - пространство
имён](N_Tessa_Extensions_Default_Shared_Workflow_KrPermissions.htm)

