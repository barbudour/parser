# KrPermissionFlagDescriptors.EditCard - поле

Редактирование данных карточки.

## __Definition

 **Пространство имён:**
[Tessa.Extensions.Default.Shared.Workflow.KrPermissions](N_Tessa_Extensions_Default_Shared_Workflow_KrPermissions.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public static readonly KrPermissionFlagDescriptor EditCard

VB __Копировать

    
    
     Public Shared ReadOnly EditCard As KrPermissionFlagDescriptor

C++ __Копировать

    
    
     public:
    static initonly KrPermissionFlagDescriptor^ EditCard

F# __Копировать

    
    
     static val EditCard: KrPermissionFlagDescriptor

#### Значение поля

[KrPermissionFlagDescriptor](T_Tessa_Extensions_Default_Shared_Workflow_KrPermissions_KrPermissionFlagDescriptor.htm)

##  __См. также

#### Ссылки

[KrPermissionFlagDescriptors -
](T_Tessa_Extensions_Default_Shared_Workflow_KrPermissions_KrPermissionFlagDescriptors.htm)

[Tessa.Extensions.Default.Shared.Workflow.KrPermissions - пространство
имён](N_Tessa_Extensions_Default_Shared_Workflow_KrPermissions.htm)

