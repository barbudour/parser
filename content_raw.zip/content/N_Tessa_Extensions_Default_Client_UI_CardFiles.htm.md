# Tessa.Extensions.Default.Client.UI.CardFiles - пространство имён

## __Классы

[CardFilesDataProvider](T_Tessa_Extensions_Default_Client_UI_CardFiles_CardFilesDataProvider.htm)|  
---|---  
[FileControlCreationParams](T_Tessa_Extensions_Default_Client_UI_CardFiles_FileControlCreationParams.htm)|  
[FilesViewCardControlInitializationStrategy](T_Tessa_Extensions_Default_Client_UI_CardFiles_FilesViewCardControlInitializationStrategy.htm)|
Стратегия инициализации модели представления  
[FilesViewGeneratorBaseUIExtension](T_Tessa_Extensions_Default_Client_UI_CardFiles_FilesViewGeneratorBaseUIExtension.htm)|
Базовый класс UI расширения для обработки расширений типа карточки "Список
файлов в представлении".  
[FilesViewMetadata](T_Tessa_Extensions_Default_Client_UI_CardFiles_FilesViewMetadata.htm)|  
[InitializeFilesViewUIExtension](T_Tessa_Extensions_Default_Client_UI_CardFiles_InitializeFilesViewUIExtension.htm)|
Реализация расширения типа карточки для преобразования представления в
файловый контрол  
[ShowContextMenuButtonViewModel](T_Tessa_Extensions_Default_Client_UI_CardFiles_ShowContextMenuButtonViewModel.htm)|
Вью-модель кнопки вызова меню файлов.  
[TableFileRowViewModel](T_Tessa_Extensions_Default_Client_UI_CardFiles_TableFileRowViewModel.htm)|
Вьюмодель для строки, связанной с файлом  
[TableFileRowViewModel.WeakListener](T_Tessa_Extensions_Default_Client_UI_CardFiles_TableFileRowViewModel_WeakListener.htm)|
Отдельный класс для IWeakEventListener, т.к. базовый класс вью модели
ViewModel`1 уже реализует интерфейс и имеет обработчик.

