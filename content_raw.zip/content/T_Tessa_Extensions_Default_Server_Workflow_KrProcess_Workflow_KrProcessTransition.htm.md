# KrProcessTransition - класс

##  __Definition

 **Пространство имён:**
[Tessa.Extensions.Default.Server.Workflow.KrProcess.Workflow](N_Tessa_Extensions_Default_Server_Workflow_KrProcess_Workflow.htm)  
 **Сборка:** Tessa.Extensions.Default.Server (в
Tessa.Extensions.Default.Server.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public static class KrProcessTransition

VB __Копировать

    
    
     Public NotInheritable Class KrProcessTransition

C++ __Копировать

    
    
     public ref class KrProcessTransition abstract sealed

F# __Копировать

    
    
     [<AbstractClassAttribute>]
    [<SealedAttribute>]
    type KrProcessTransition = class end

Inheritance

    [Object](https://learn.microsoft.com/dotnet/api/system.object) __ KrProcessTransition

##  __Поля

[CompleteProcess](F_Tessa_Extensions_Default_Server_Workflow_KrProcess_Workflow_KrProcessTransition_CompleteProcess.htm)|  
---|---  
[NextStage](F_Tessa_Extensions_Default_Server_Workflow_KrProcess_Workflow_KrProcessTransition_NextStage.htm)|  
  
## __См. также

#### Ссылки

[Tessa.Extensions.Default.Server.Workflow.KrProcess.Workflow - пространство
имён](N_Tessa_Extensions_Default_Server_Workflow_KrProcess_Workflow.htm)

