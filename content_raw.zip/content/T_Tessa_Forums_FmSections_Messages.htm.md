# FmSections.Messages - класс

##  __Definition

 **Пространство имён:** [Tessa.Forums](N_Tessa_Forums.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public static class Messages

VB __Копировать

    
    
     Public NotInheritable Class Messages

C++ __Копировать

    
    
     public ref class Messages abstract sealed

F# __Копировать

    
    
     [<AbstractClassAttribute>]
    [<SealedAttribute>]
    type Messages = class end

Inheritance

    [Object](https://learn.microsoft.com/dotnet/api/system.object) __ FmSections.Messages

##  __Поля

[AuthorID](F_Tessa_Forums_FmSections_Messages_AuthorID.htm)|  
---|---  
[AuthorName](F_Tessa_Forums_FmSections_Messages_AuthorName.htm)|  
[Body](F_Tessa_Forums_FmSections_Messages_Body.htm)|  
[Created](F_Tessa_Forums_FmSections_Messages_Created.htm)|  
[ID](F_Tessa_Forums_FmSections_Messages_ID.htm)|  
[ModifiedAt](F_Tessa_Forums_FmSections_Messages_ModifiedAt.htm)|  
[ModifiedByID](F_Tessa_Forums_FmSections_Messages_ModifiedByID.htm)|  
[ModifiedByName](F_Tessa_Forums_FmSections_Messages_ModifiedByName.htm)|  
[PlainText](F_Tessa_Forums_FmSections_Messages_PlainText.htm)|  
[SatelliteID](F_Tessa_Forums_FmSections_Messages_SatelliteID.htm)|  
[TopicID](F_Tessa_Forums_FmSections_Messages_TopicID.htm)|  
[Type](F_Tessa_Forums_FmSections_Messages_Type.htm)|  
  
## __См. также

#### Ссылки

[Tessa.Forums - пространство имён](N_Tessa_Forums.htm)

