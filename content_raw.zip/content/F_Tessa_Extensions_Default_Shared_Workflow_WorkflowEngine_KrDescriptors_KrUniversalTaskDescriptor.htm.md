# KrDescriptors.KrUniversalTaskDescriptor - поле

Настраиваемое задание.

## __Definition

 **Пространство имён:**
[Tessa.Extensions.Default.Shared.Workflow.WorkflowEngine](N_Tessa_Extensions_Default_Shared_Workflow_WorkflowEngine.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public static readonly WorkflowActionDescriptor KrUniversalTaskDescriptor

VB __Копировать

    
    
     Public Shared ReadOnly KrUniversalTaskDescriptor As WorkflowActionDescriptor

C++ __Копировать

    
    
     public:
    static initonly WorkflowActionDescriptor^ KrUniversalTaskDescriptor

F# __Копировать

    
    
     static val KrUniversalTaskDescriptor: WorkflowActionDescriptor

#### Значение поля

[WorkflowActionDescriptor](T_Tessa_Workflow_Actions_Descriptors_WorkflowActionDescriptor.htm)

##  __См. также

#### Ссылки

[KrDescriptors -
](T_Tessa_Extensions_Default_Shared_Workflow_WorkflowEngine_KrDescriptors.htm)

[Tessa.Extensions.Default.Shared.Workflow.WorkflowEngine - пространство
имён](N_Tessa_Extensions_Default_Shared_Workflow_WorkflowEngine.htm)

