#
StorageSchemaConstants.ApplicationPackageSchemeConstants.SourceTypeIdAttribute
- поле

Имя атрибута содержащего местоположение файла

## __Definition

 **Пространство имён:** [Tessa.Applications](N_Tessa_Applications.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public const string SourceTypeIdAttribute = "SourceTypeId"

VB __Копировать

    
    
     Public Const SourceTypeIdAttribute As String = "SourceTypeId"

C++ __Копировать

    
    
     public:
    literal String^ SourceTypeIdAttribute = "SourceTypeId"

F# __Копировать

    
    
     static val mutable SourceTypeIdAttribute: string

#### Значение поля

[String](https://learn.microsoft.com/dotnet/api/system.string)

##  __См. также

#### Ссылки

[StorageSchemaConstants.ApplicationPackageSchemeConstants -
](T_Tessa_Applications_StorageSchemaConstants_ApplicationPackageSchemeConstants.htm)

[Tessa.Applications - пространство имён](N_Tessa_Applications.htm)

