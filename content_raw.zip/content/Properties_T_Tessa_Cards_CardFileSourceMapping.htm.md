# CardFileSourceMapping - свойства

##  __Свойства

[IsSealed](P_Tessa_Cards_CardFileSourceMapping_IsSealed.htm)| Признак того,
что объект был защищён от изменений.  
---|---  
  
##  __См. также

#### Ссылки

[CardFileSourceMapping - ](T_Tessa_Cards_CardFileSourceMapping.htm)

[Tessa.Cards - пространство имён](N_Tessa_Cards.htm)

