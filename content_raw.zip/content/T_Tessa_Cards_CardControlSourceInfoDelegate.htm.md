# CardControlSourceInfoDelegate - делегат

##  __Definition

 **Пространство имён:** [Tessa.Cards](N_Tessa_Cards.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public delegate CardControlSourceInfo CardControlSourceInfoDelegate(
    	CardTypeControl control
    )

VB __Копировать

    
    
     Public Delegate Function CardControlSourceInfoDelegate ( 
    	control As CardTypeControl
    ) As CardControlSourceInfo

C++ __Копировать

    
    
     public delegate CardControlSourceInfo^ CardControlSourceInfoDelegate(
    	CardTypeControl^ control
    )

F# __Копировать

    
    
     type CardControlSourceInfoDelegate = 
        delegate of 
            control : CardTypeControl -> CardControlSourceInfo

#### Параметры

control [CardTypeControl](T_Tessa_Cards_CardTypeControl.htm)

    

#### Возвращаемое значение

[CardControlSourceInfo](T_Tessa_Cards_CardControlSourceInfo.htm)

##  __См. также

#### Ссылки

[Tessa.Cards - пространство имён](N_Tessa_Cards.htm)

