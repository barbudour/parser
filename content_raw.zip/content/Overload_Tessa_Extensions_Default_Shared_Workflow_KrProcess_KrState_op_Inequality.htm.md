# KrState.Inequality - оператор

##  __Список перегрузок

[Inequality(Int32,
KrState)](M_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrState_op_Inequality.htm)|  
---|---  
[Inequality(KrState,
Int32)](M_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrState_op_Inequality_1.htm)|  
[Inequality(KrState,
KrState)](M_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrState_op_Inequality_2.htm)|  
  
## __См. также

#### Ссылки

[KrState - ](T_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrState.htm)

[Tessa.Extensions.Default.Shared.Workflow.KrProcess - пространство
имён](N_Tessa_Extensions_Default_Shared_Workflow_KrProcess.htm)

