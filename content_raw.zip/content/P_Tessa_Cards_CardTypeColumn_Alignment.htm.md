# CardTypeColumn.Alignment - свойство

Выравнивание содержимого, отображаемого в колонке.

## __Definition

 **Пространство имён:** [Tessa.Cards](N_Tessa_Cards.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public CardTypeColumnAlignment Alignment { get; set; }

VB __Копировать

    
    
     Public Property Alignment As CardTypeColumnAlignment
    	Get
    	Set

C++ __Копировать

    
    
     public:
    property CardTypeColumnAlignment Alignment {
    	CardTypeColumnAlignment get ();
    	void set (CardTypeColumnAlignment value);
    }

F# __Копировать

    
    
     member Alignment : CardTypeColumnAlignment with get, set

#### Значение свойства

[CardTypeColumnAlignment](T_Tessa_Cards_CardTypeColumnAlignment.htm)

##  __Исключения

[Tessa.Platform.ObjectSealedException]| Произведена попытка изменения объекта,
защищённого от изменений.  
---|---  
  
##  __См. также

#### Ссылки

[CardTypeColumn - ](T_Tessa_Cards_CardTypeColumn.htm)

[Tessa.Cards - пространство имён](N_Tessa_Cards.htm)

[Tessa.Platform.ObjectSealedException]

