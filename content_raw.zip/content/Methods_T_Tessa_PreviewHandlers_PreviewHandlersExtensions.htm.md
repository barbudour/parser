# PreviewHandlersExtensions - методы

##  __Методы

[CreateHostPreviewServiceRouter](M_Tessa_PreviewHandlers_PreviewHandlersExtensions_CreateHostPreviewServiceRouter.htm)|  
---|---  
[RegisterPreviewHandlers](M_Tessa_PreviewHandlers_PreviewHandlersExtensions_RegisterPreviewHandlers.htm)|  
  
## __См. также

#### Ссылки

[PreviewHandlersExtensions -
](T_Tessa_PreviewHandlers_PreviewHandlersExtensions.htm)

[Tessa.PreviewHandlers - пространство имён](N_Tessa_PreviewHandlers.htm)

