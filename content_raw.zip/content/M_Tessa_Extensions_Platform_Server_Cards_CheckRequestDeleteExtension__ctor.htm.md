# CheckRequestDeleteExtension - конструктор

Инициализирует новый экземпляр класса
[CheckRequestDeleteExtension](T_Tessa_Extensions_Platform_Server_Cards_CheckRequestDeleteExtension.htm)

##  __Definition

 **Пространство имён:**
[Tessa.Extensions.Platform.Server.Cards](N_Tessa_Extensions_Platform_Server_Cards.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public CheckRequestDeleteExtension()

VB __Копировать

    
    
     Public Sub New

C++ __Копировать

    
    
     public:
    CheckRequestDeleteExtension()

F# __Копировать

    
    
     new : unit -> CheckRequestDeleteExtension

##  __См. также

#### Ссылки

[CheckRequestDeleteExtension -
](T_Tessa_Extensions_Platform_Server_Cards_CheckRequestDeleteExtension.htm)

[Tessa.Extensions.Platform.Server.Cards - пространство
имён](N_Tessa_Extensions_Platform_Server_Cards.htm)

