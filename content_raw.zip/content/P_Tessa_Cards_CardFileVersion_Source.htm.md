# CardFileVersion.Source - свойство

Местоположение контента версии файла.

## __Definition

 **Пространство имён:** [Tessa.Cards](N_Tessa_Cards.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public CardFileSourceType Source { get; set; }

VB __Копировать

    
    
     Public Property Source As CardFileSourceType
    	Get
    	Set

C++ __Копировать

    
    
     public:
    property CardFileSourceType Source {
    	CardFileSourceType get ();
    	void set (CardFileSourceType value);
    }

F# __Копировать

    
    
     member Source : CardFileSourceType with get, set

#### Значение свойства

[CardFileSourceType](T_Tessa_Cards_CardFileSourceType.htm)

##  __Заметки

По умолчанию установлено значение Database.

## __См. также

#### Ссылки

[CardFileVersion - ](T_Tessa_Cards_CardFileVersion.htm)

[Tessa.Cards - пространство имён](N_Tessa_Cards.htm)

