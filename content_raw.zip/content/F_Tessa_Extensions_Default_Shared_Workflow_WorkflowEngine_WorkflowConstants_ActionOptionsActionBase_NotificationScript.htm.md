# WorkflowConstants.ActionOptionsActionBase.NotificationScript - поле

##  __Definition

 **Пространство имён:**
[Tessa.Extensions.Default.Shared.Workflow.WorkflowEngine](N_Tessa_Extensions_Default_Shared_Workflow_WorkflowEngine.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public const string NotificationScript = "NotificationScript"

VB __Копировать

    
    
     Public Const NotificationScript As String = "NotificationScript"

C++ __Копировать

    
    
     public:
    literal String^ NotificationScript = "NotificationScript"

F# __Копировать

    
    
     static val mutable NotificationScript: string

#### Значение поля

[String](https://learn.microsoft.com/dotnet/api/system.string)

##  __См. также

#### Ссылки

[WorkflowConstants.ActionOptionsActionBase -
](T_Tessa_Extensions_Default_Shared_Workflow_WorkflowEngine_WorkflowConstants_ActionOptionsActionBase.htm)

[Tessa.Extensions.Default.Shared.Workflow.WorkflowEngine - пространство
имён](N_Tessa_Extensions_Default_Shared_Workflow_WorkflowEngine.htm)

