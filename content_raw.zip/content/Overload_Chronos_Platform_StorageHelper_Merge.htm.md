# StorageHelper.Merge - метод

##  __Список перегрузок

[Merge(IEnumerable, IList)](M_Chronos_Platform_StorageHelper_Merge_1.htm)|
Выполняет слияние данных из хранилища source в коллекцию объектов target.  
---|---  
[Merge(IDictionary<String, Object>, IDictionary<String, Object>,
Boolean)](M_Chronos_Platform_StorageHelper_Merge.htm)|  Выполняет слияние
данных из хранилища source в коллекцию ключ / значение target.  
  
## __См. также

#### Ссылки

[StorageHelper - ](T_Chronos_Platform_StorageHelper.htm)

[Chronos.Platform - пространство имён](N_Chronos_Platform.htm)

