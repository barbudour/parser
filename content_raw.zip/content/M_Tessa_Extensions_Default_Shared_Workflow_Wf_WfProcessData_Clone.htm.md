# WfProcessData.Clone - метод

##  __Definition

 **Пространство имён:**
[Tessa.Extensions.Default.Shared.Workflow.Wf](N_Tessa_Extensions_Default_Shared_Workflow_Wf.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public WfProcessData Clone()

VB __Копировать

    
    
     Public Function Clone As WfProcessData

C++ __Копировать

    
    
     public:
    WfProcessData^ Clone()

F# __Копировать

    
    
     member Clone : unit -> WfProcessData 

#### Возвращаемое значение

[WfProcessData](T_Tessa_Extensions_Default_Shared_Workflow_Wf_WfProcessData.htm)

##  __См. также

#### Ссылки

[WfProcessData -
](T_Tessa_Extensions_Default_Shared_Workflow_Wf_WfProcessData.htm)

[Tessa.Extensions.Default.Shared.Workflow.Wf - пространство
имён](N_Tessa_Extensions_Default_Shared_Workflow_Wf.htm)

