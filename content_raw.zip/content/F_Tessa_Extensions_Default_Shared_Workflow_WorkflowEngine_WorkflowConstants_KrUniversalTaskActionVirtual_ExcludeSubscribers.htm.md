# WorkflowConstants.KrUniversalTaskActionVirtual.ExcludeSubscribers - поле

##  __Definition

 **Пространство имён:**
[Tessa.Extensions.Default.Shared.Workflow.WorkflowEngine](N_Tessa_Extensions_Default_Shared_Workflow_WorkflowEngine.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public const string ExcludeSubscribers = "ExcludeSubscribers"

VB __Копировать

    
    
     Public Const ExcludeSubscribers As String = "ExcludeSubscribers"

C++ __Копировать

    
    
     public:
    literal String^ ExcludeSubscribers = "ExcludeSubscribers"

F# __Копировать

    
    
     static val mutable ExcludeSubscribers: string

#### Значение поля

[String](https://learn.microsoft.com/dotnet/api/system.string)

##  __См. также

#### Ссылки

[WorkflowConstants.KrUniversalTaskActionVirtual -
](T_Tessa_Extensions_Default_Shared_Workflow_WorkflowEngine_WorkflowConstants_KrUniversalTaskActionVirtual.htm)

[Tessa.Extensions.Default.Shared.Workflow.WorkflowEngine - пространство
имён](N_Tessa_Extensions_Default_Shared_Workflow_WorkflowEngine.htm)

