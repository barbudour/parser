# CardCompilationHelper.CompileFileNameKey - поле

##  __Definition

 **Пространство имён:**
[Tessa.Extensions.Platform.Server.Cards](N_Tessa_Extensions_Platform_Server_Cards.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17

C# __Копировать

    
    
     public const string CompileFileNameKey = ".CompileFile"

VB __Копировать

    
    
     Public Const CompileFileNameKey As String = ".CompileFile"

C++ __Копировать

    
    
     public:
    literal String^ CompileFileNameKey = ".CompileFile"

F# __Копировать

    
    
     static val mutable CompileFileNameKey: string

#### Значение поля

[String](https://learn.microsoft.com/dotnet/api/system.string)

##  __См. также

#### Ссылки

[CardCompilationHelper -
](T_Tessa_Extensions_Platform_Server_Cards_CardCompilationHelper.htm)

[Tessa.Extensions.Platform.Server.Cards - пространство
имён](N_Tessa_Extensions_Platform_Server_Cards.htm)

