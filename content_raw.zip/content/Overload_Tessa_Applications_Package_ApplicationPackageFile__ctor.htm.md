# ApplicationPackageFile - конструктор

##  __Список перегрузок

[ApplicationPackageFile()](M_Tessa_Applications_Package_ApplicationPackageFile__ctor.htm)|
Initializes a new instance of the
[ApplicationPackageFile](T_Tessa_Applications_Package_ApplicationPackageFile.htm)
class. Initializes a new instance of the
[Object](https://learn.microsoft.com/dotnet/api/system.object) class.  
---|---  
[ApplicationPackageFile(String, String, Guid, Int64, Byte[], Nullable<Guid>,
Nullable<Guid>, Nullable<CardFileSourceType>, PackageFileState,
Boolean)](M_Tessa_Applications_Package_ApplicationPackageFile__ctor_1.htm)|
Initializes a new instance of the
[ApplicationPackageFile](T_Tessa_Applications_Package_ApplicationPackageFile.htm)
class. Инициализирует новый экземпляр класса
[Object](https://learn.microsoft.com/dotnet/api/system.object).  
  
## __См. также

#### Ссылки

[ApplicationPackageFile -
](T_Tessa_Applications_Package_ApplicationPackageFile.htm)

[Tessa.Applications.Package - пространство
имён](N_Tessa_Applications_Package.htm)

