# IExtensionAssemblyInfo - методы

##  __Методы

[Register](M_Tessa_Extensions_IExtensionAssemblyInfo_Register.htm)|
Регистрирует сборку расширений с указанием места её использования.  
---|---  
  
##  __См. также

#### Ссылки

[IExtensionAssemblyInfo - ](T_Tessa_Extensions_IExtensionAssemblyInfo.htm)

[Tessa.Extensions - пространство имён](N_Tessa_Extensions.htm)

