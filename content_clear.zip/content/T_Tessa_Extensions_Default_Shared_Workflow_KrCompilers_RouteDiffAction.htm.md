# RouteDiffAction - перечисление
Тип действия с этапом маршрута.
## __Definition
 **Пространство имён:**
[Tessa.Extensions.Default.Shared.Workflow.KrCompilers](N_Tessa_Extensions_Default_Shared_Workflow_KrCompilers.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17
C# __Копировать
     public enum RouteDiffAction
VB __Копировать
     Public Enumeration RouteDiffAction
C++ __Копировать
     public enum class RouteDiffAction
F# __Копировать
     type RouteDiffAction
##  __Члены
Insert| 0|  Этап был добавлен.  
---|---|---  
Delete| 1|  Этап был удалён.  
Modify| 2|  Этап был изменён.  
## __См. также
#### Ссылки
[Tessa.Extensions.Default.Shared.Workflow.KrCompilers - пространство
имён](N_Tessa_Extensions_Default_Shared_Workflow_KrCompilers.htm)
