# UriLinkEventArgs - свойства
##  __Свойства
[Cancel](P_Tessa_Platform_DeferredCancelEventArgs_Cancel.htm)|  Признак того,
что действие отменяется.  
(Унаследован от
[DeferredCancelEventArgs](T_Tessa_Platform_DeferredCancelEventArgs.htm))  
---|---  
[Uri](P_Tessa_UriLinks_UriLinkEventArgs_Uri.htm)|  Объект, описывающий ссылку.  
## __См. также
#### Ссылки
[UriLinkEventArgs - ](T_Tessa_UriLinks_UriLinkEventArgs.htm)
[Tessa.UriLinks - пространство имён](N_Tessa_UriLinks.htm)
