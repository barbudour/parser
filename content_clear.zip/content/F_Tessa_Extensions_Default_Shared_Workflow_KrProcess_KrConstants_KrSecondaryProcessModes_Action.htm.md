# KrConstants.KrSecondaryProcessModes.Action - поле
##  __Definition
 **Пространство имён:**
[Tessa.Extensions.Default.Shared.Workflow.KrProcess](N_Tessa_Extensions_Default_Shared_Workflow_KrProcess.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17
C# __Копировать
     public static readonly KrConstants.KrSecondaryProcessModes.Entry Action
VB __Копировать
     Public Shared ReadOnly Action As KrConstants.KrSecondaryProcessModes.Entry
C++ __Копировать
     public:
    static initonly KrConstants.KrSecondaryProcessModes.Entry^ Action
F# __Копировать
     static val Action: KrConstants.KrSecondaryProcessModes.Entry
#### Значение поля
[KrConstants.KrSecondaryProcessModes.Entry](T_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrConstants_KrSecondaryProcessModes_Entry.htm)
##  __См. также
#### Ссылки
[KrConstants.KrSecondaryProcessModes -
](T_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrConstants_KrSecondaryProcessModes.htm)
[Tessa.Extensions.Default.Shared.Workflow.KrProcess - пространство
имён](N_Tessa_Extensions_Default_Shared_Workflow_KrProcess.htm)
