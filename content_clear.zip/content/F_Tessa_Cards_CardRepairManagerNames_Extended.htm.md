# CardRepairManagerNames.Extended - поле
Объект с расширениями (платформенными и пользовательскими).
## __Definition
 **Пространство имён:** [Tessa.Cards](N_Tessa_Cards.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17
C# __Копировать
     public const string Extended = "Extended"
VB __Копировать
     Public Const Extended As String = "Extended"
C++ __Копировать
     public:
    literal String^ Extended = "Extended"
F# __Копировать
     static val mutable Extended: string
#### Значение поля
[String](https://learn.microsoft.com/dotnet/api/system.string)
##  __См. также
#### Ссылки
[CardRepairManagerNames - ](T_Tessa_Cards_CardRepairManagerNames.htm)
[Tessa.Cards - пространство имён](N_Tessa_Cards.htm)
