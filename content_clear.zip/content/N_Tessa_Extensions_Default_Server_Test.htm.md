# Tessa.Extensions.Default.Server.Test - пространство имён
Расширения типового решения на сервере, связанные с тестовыми примерами
расширений.
##  __Классы
[Registrator](T_Tessa_Extensions_Default_Server_Test_Registrator.htm)|  
---|---  
[TestDataRequestExtension](T_Tessa_Extensions_Default_Server_Test_TestDataRequestExtension.htm)|  
[Xml1CProvider](T_Tessa_Extensions_Default_Server_Test_Xml1CProvider.htm)|  
[XmlFrom1CRequestExtension](T_Tessa_Extensions_Default_Server_Test_XmlFrom1CRequestExtension.htm)|
Расширение на сохранение фейковой карточки, которое возвращает нужные нам
данные. Это расширение на сохранение, а не на загрузку, т.к. расширение на
загрузку обязано вернуть корректный пакет карточки.
