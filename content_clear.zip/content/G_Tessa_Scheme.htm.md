# Tessa.Scheme - пространства имён
API для взаимодействия со схемой (структурой) метаданных таблиц.
##  __Пространства имён
[Tessa.Scheme](N_Tessa_Scheme.htm)| API для взаимодействия со схемой
(структурой) метаданных таблиц.  
---|---  
[Tessa.Scheme.Differences](N_Tessa_Scheme_Differences.htm)| Очереди изменений
для API схемы.
