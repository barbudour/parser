# CardTypeExtensionTypeRegistry - свойства
##  __Свойства
[Instance](P_Tessa_Cards_CardTypeExtensionTypeRegistry_Instance.htm)|
Экземпляр класса.  
---|---  
##  __См. также
#### Ссылки
[CardTypeExtensionTypeRegistry -
](T_Tessa_Cards_CardTypeExtensionTypeRegistry.htm)
[Tessa.Cards - пространство имён](N_Tessa_Cards.htm)
