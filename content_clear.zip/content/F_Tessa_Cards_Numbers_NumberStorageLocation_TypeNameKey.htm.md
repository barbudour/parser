# NumberStorageLocation.TypeNameKey - поле
##  __Definition
 **Пространство имён:** [Tessa.Cards.Numbers](N_Tessa_Cards_Numbers.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17
C# __Копировать
     public const string TypeNameKey = "TypeName"
VB __Копировать
     Public Const TypeNameKey As String = "TypeName"
C++ __Копировать
     public:
    literal String^ TypeNameKey = "TypeName"
F# __Копировать
     static val mutable TypeNameKey: string
#### Значение поля
[String](https://learn.microsoft.com/dotnet/api/system.string)
##  __См. также
#### Ссылки
[NumberStorageLocation - ](T_Tessa_Cards_Numbers_NumberStorageLocation.htm)
[Tessa.Cards.Numbers - пространство имён](N_Tessa_Cards_Numbers.htm)
