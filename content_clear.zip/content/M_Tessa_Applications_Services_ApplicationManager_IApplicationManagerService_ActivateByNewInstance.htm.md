# IApplicationManagerService.ActivateByNewInstance - метод
Активизирует приложение с уведомлением о запуске от нового экземпляра
приложения
## __Definition
 **Пространство имён:**
[Tessa.Applications.Services.ApplicationManager](N_Tessa_Applications_Services_ApplicationManager.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17
C# __Копировать
    [OperationContractAttribute(IsOneWay = true)]
    void ActivateByNewInstance()
VB __Копировать
    <OperationContractAttribute(IsOneWay := true)>
    Sub ActivateByNewInstance
C++ __Копировать
    [OperationContractAttribute(IsOneWay = true)]
    void ActivateByNewInstance()
F# __Копировать
     [<OperationContractAttribute(IsOneWay = true)>]
    abstract ActivateByNewInstance : unit -> unit 
## __См. также
#### Ссылки
[IApplicationManagerService -
](T_Tessa_Applications_Services_ApplicationManager_IApplicationManagerService.htm)
[Tessa.Applications.Services.ApplicationManager - пространство
имён](N_Tessa_Applications_Services_ApplicationManager.htm)
