# CardNewStrategy.Default - свойство
Стратегия по умолчанию, не выполняющая кэширование результатов.
## __Definition
 **Пространство имён:**
[Tessa.Cards.ComponentModel](N_Tessa_Cards_ComponentModel.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17
C# __Копировать
     public static ICardNewStrategy Default { get; }
VB __Копировать
     Public Shared ReadOnly Property Default As ICardNewStrategy
    	Get
C++ __Копировать
     public:
    static property ICardNewStrategy^ Default {
    	ICardNewStrategy^ get ();
    }
F# __Копировать
     static member Default : ICardNewStrategy with get
#### Значение свойства
[ICardNewStrategy](T_Tessa_Cards_ComponentModel_ICardNewStrategy.htm)
##  __См. также
#### Ссылки
[CardNewStrategy - ](T_Tessa_Cards_ComponentModel_CardNewStrategy.htm)
[Tessa.Cards.ComponentModel - пространство
имён](N_Tessa_Cards_ComponentModel.htm)
