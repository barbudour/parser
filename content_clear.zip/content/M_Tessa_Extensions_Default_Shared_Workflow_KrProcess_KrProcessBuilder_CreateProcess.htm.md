# KrProcessBuilder.CreateProcess - метод
Создаёт построитель процесса.
## __Definition
 **Пространство имён:**
[Tessa.Extensions.Default.Shared.Workflow.KrProcess](N_Tessa_Extensions_Default_Shared_Workflow_KrProcess.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17
C# __Копировать
     public static KrProcessBuilder CreateProcess()
VB __Копировать
     Public Shared Function CreateProcess As KrProcessBuilder
C++ __Копировать
     public:
    static KrProcessBuilder^ CreateProcess()
F# __Копировать
     static member CreateProcess : unit -> KrProcessBuilder 
#### Возвращаемое значение
[KrProcessBuilder](T_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrProcessBuilder.htm)  
Объект
[KrProcessBuilder](T_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrProcessBuilder.htm)
для создания цепочки.
##  __См. также
#### Ссылки
[KrProcessBuilder -
](T_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrProcessBuilder.htm)
[Tessa.Extensions.Default.Shared.Workflow.KrProcess - пространство
имён](N_Tessa_Extensions_Default_Shared_Workflow_KrProcess.htm)
