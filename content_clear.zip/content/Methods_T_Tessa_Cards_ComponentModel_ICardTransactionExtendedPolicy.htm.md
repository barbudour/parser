# ICardTransactionExtendedPolicy - методы
##  __Методы
[AfterBeginTransactionAsync](M_Tessa_Cards_ComponentModel_ICardTransactionExtendedPolicy_AfterBeginTransactionAsync.htm)|
Метод, выполняющий расширения после начала транзакции, но перед выполнением
действий с карточкой.  
---|---  
[BeforeCommitTransactionAsync](M_Tessa_Cards_ComponentModel_ICardTransactionExtendedPolicy_BeforeCommitTransactionAsync.htm)|
Метод, выполняющий расширения перед коммитом транзакции после выполнения
действий с карточкой.  
##  __См. также
#### Ссылки
[ICardTransactionExtendedPolicy -
](T_Tessa_Cards_ComponentModel_ICardTransactionExtendedPolicy.htm)
[Tessa.Cards.ComponentModel - пространство
имён](N_Tessa_Cards_ComponentModel.htm)
