# NoneFileMergeResultItem - свойства
##  __Свойства
[File](P_Tessa_Cards_SmartMerge_MergeResultItems_Files_FileMergeResultItemBase_File.htm)|
Файл из объекта-источника.  
(Унаследован от
[FileMergeResultItemBase](T_Tessa_Cards_SmartMerge_MergeResultItems_Files_FileMergeResultItemBase.htm))  
---|---  
[ReferenceRowID](P_Tessa_Cards_SmartMerge_MergeResultItems_Files_FileMergeResultItemBase_ReferenceRowID.htm)|
RowID соотнесенного файла.  
(Унаследован от
[FileMergeResultItemBase](T_Tessa_Cards_SmartMerge_MergeResultItems_Files_FileMergeResultItemBase.htm))  
##  __См. также
#### Ссылки
[NoneFileMergeResultItem -
](T_Tessa_Cards_SmartMerge_MergeResultItems_Files_NoneFileMergeResultItem.htm)
[Tessa.Cards.SmartMerge.MergeResultItems.Files - пространство
имён](N_Tessa_Cards_SmartMerge_MergeResultItems_Files.htm)
