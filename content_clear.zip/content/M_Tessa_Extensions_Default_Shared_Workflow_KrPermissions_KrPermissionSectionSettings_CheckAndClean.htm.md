# KrPermissionSectionSettings.CheckAndClean - метод
##  __Definition
 **Пространство имён:**
[Tessa.Extensions.Default.Shared.Workflow.KrPermissions](N_Tessa_Extensions_Default_Shared_Workflow_KrPermissions.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17
C# __Копировать
     public bool CheckAndClean(
    	CardType cardType
    )
VB __Копировать
     Public Function CheckAndClean ( 
    	cardType As CardType
    ) As Boolean
C++ __Копировать
     public:
    bool CheckAndClean(
    	CardType^ cardType
    )
F# __Копировать
     member CheckAndClean : 
            cardType : CardType -> bool 
#### Параметры
cardType [CardType](T_Tessa_Cards_CardType.htm)
#### Возвращаемое значение
[Boolean](https://learn.microsoft.com/dotnet/api/system.boolean)
##  __См. также
#### Ссылки
[KrPermissionSectionSettings -
](T_Tessa_Extensions_Default_Shared_Workflow_KrPermissions_KrPermissionSectionSettings.htm)
[Tessa.Extensions.Default.Shared.Workflow.KrPermissions - пространство
имён](N_Tessa_Extensions_Default_Shared_Workflow_KrPermissions.htm)
