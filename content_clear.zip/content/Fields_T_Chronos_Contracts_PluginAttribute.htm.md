# PluginAttribute - поля
##  __Поля
[UnnamedPluginName](F_Chronos_Contracts_PluginAttribute_UnnamedPluginName.htm)|
Имя плагина по умолчанию.  
---|---  
## __См. также
#### Ссылки
[PluginAttribute - ](T_Chronos_Contracts_PluginAttribute.htm)
[Chronos.Contracts - пространство имён](N_Chronos_Contracts.htm)
