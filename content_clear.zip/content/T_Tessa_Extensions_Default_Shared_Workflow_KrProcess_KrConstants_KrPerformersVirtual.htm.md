# KrConstants.KrPerformersVirtual - класс
##  __Definition
 **Пространство имён:**
[Tessa.Extensions.Default.Shared.Workflow.KrProcess](N_Tessa_Extensions_Default_Shared_Workflow_KrProcess.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17
C# __Копировать
     public static class KrPerformersVirtual
VB __Копировать
     Public NotInheritable Class KrPerformersVirtual
C++ __Копировать
     public ref class KrPerformersVirtual abstract sealed
F# __Копировать
     [<AbstractClassAttribute>]
    [<SealedAttribute>]
    type KrPerformersVirtual = class end
Inheritance
    [Object](https://learn.microsoft.com/dotnet/api/system.object) __ KrConstants.KrPerformersVirtual
##  __Поля
[ID](F_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrConstants_KrPerformersVirtual_ID.htm)|  
---|---  
[Name](F_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrConstants_KrPerformersVirtual_Name.htm)|  
[Order](F_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrConstants_KrPerformersVirtual_Order.htm)|  
[PerformerID](F_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrConstants_KrPerformersVirtual_PerformerID.htm)|  
[PerformerName](F_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrConstants_KrPerformersVirtual_PerformerName.htm)|  
[RowID](F_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrConstants_KrPerformersVirtual_RowID.htm)|  
[SQLApprover](F_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrConstants_KrPerformersVirtual_SQLApprover.htm)|  
[StageRowID](F_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrConstants_KrPerformersVirtual_StageRowID.htm)|  
[Synthetic](F_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrConstants_KrPerformersVirtual_Synthetic.htm)|  
## __См. также
#### Ссылки
[Tessa.Extensions.Default.Shared.Workflow.KrProcess - пространство
имён](N_Tessa_Extensions_Default_Shared_Workflow_KrProcess.htm)
