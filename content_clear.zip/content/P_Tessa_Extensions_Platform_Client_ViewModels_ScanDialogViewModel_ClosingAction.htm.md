# ScanDialogViewModel.ClosingAction - свойство
Действие при закрытии диалога.
## __Definition
 **Пространство имён:**
[Tessa.Extensions.Platform.Client.ViewModels](N_Tessa_Extensions_Platform_Client_ViewModels.htm)  
 **Сборка:** Tessa.UI (в Tessa.UI.dll) Версия: 3.6.0.17
C# __Копировать
     public ScanDialogClosingAction ClosingAction { get; set; }
VB __Копировать
     Public Property ClosingAction As ScanDialogClosingAction
    	Get
    	Set
C++ __Копировать
     public:
    property ScanDialogClosingAction ClosingAction {
    	ScanDialogClosingAction get ();
    	void set (ScanDialogClosingAction value);
    }
F# __Копировать
     member ClosingAction : ScanDialogClosingAction with get, set
#### Значение свойства
[ScanDialogClosingAction](T_Tessa_Extensions_Platform_Client_ViewModels_ScanDialogClosingAction.htm)
##  __См. также
#### Ссылки
[ScanDialogViewModel -
](T_Tessa_Extensions_Platform_Client_ViewModels_ScanDialogViewModel.htm)
[Tessa.Extensions.Platform.Client.ViewModels - пространство
имён](N_Tessa_Extensions_Platform_Client_ViewModels.htm)
