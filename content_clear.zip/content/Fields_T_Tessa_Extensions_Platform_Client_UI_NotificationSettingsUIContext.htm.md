# NotificationSettingsUIContext - поля
##  __Поля
[card](F_Tessa_Extensions_Platform_Client_UI_ConditionsUIContext_card.htm)|  
(Унаследован от
[ConditionsUIContext](T_Tessa_Extensions_Platform_Client_UI_ConditionsUIContext.htm))  
---|---  
[cardMetadata](F_Tessa_Extensions_Platform_Client_UI_ConditionsUIContext_cardMetadata.htm)|  
(Унаследован от
[ConditionsUIContext](T_Tessa_Extensions_Platform_Client_UI_ConditionsUIContext.htm))  
[cardModel](F_Tessa_Extensions_Platform_Client_UI_ConditionsUIContext_cardModel.htm)|  
(Унаследован от
[ConditionsUIContext](T_Tessa_Extensions_Platform_Client_UI_ConditionsUIContext.htm))  
[cardRepairManager](F_Tessa_Extensions_Platform_Client_UI_ConditionsUIContext_cardRepairManager.htm)|  
(Унаследован от
[ConditionsUIContext](T_Tessa_Extensions_Platform_Client_UI_ConditionsUIContext.htm))  
[conditionRow](F_Tessa_Extensions_Platform_Client_UI_ConditionsUIContext_conditionRow.htm)|  
(Унаследован от
[ConditionsUIContext](T_Tessa_Extensions_Platform_Client_UI_ConditionsUIContext.htm))  
[conditionRowModel](F_Tessa_Extensions_Platform_Client_UI_ConditionsUIContext_conditionRowModel.htm)|  
(Унаследован от
[ConditionsUIContext](T_Tessa_Extensions_Platform_Client_UI_ConditionsUIContext.htm))  
[conditionsSection](F_Tessa_Extensions_Platform_Client_UI_ConditionsUIContext_conditionsSection.htm)|  
(Унаследован от
[ConditionsUIContext](T_Tessa_Extensions_Platform_Client_UI_ConditionsUIContext.htm))  
[conditionsTable](F_Tessa_Extensions_Platform_Client_UI_ConditionsUIContext_conditionsTable.htm)|  
(Унаследован от
[ConditionsUIContext](T_Tessa_Extensions_Platform_Client_UI_ConditionsUIContext.htm))  
[placeholderManager](F_Tessa_Extensions_Platform_Client_UI_ConditionsUIContext_placeholderManager.htm)|  
(Унаследован от
[ConditionsUIContext](T_Tessa_Extensions_Platform_Client_UI_ConditionsUIContext.htm))  
[session](F_Tessa_Extensions_Platform_Client_UI_ConditionsUIContext_session.htm)|  
(Унаследован от
[ConditionsUIContext](T_Tessa_Extensions_Platform_Client_UI_ConditionsUIContext.htm))  
[typesProvider](F_Tessa_Extensions_Platform_Client_UI_ConditionsUIContext_typesProvider.htm)|  
(Унаследован от
[ConditionsUIContext](T_Tessa_Extensions_Platform_Client_UI_ConditionsUIContext.htm))  
[unityContainer](F_Tessa_Extensions_Platform_Client_UI_ConditionsUIContext_unityContainer.htm)|  
(Унаследован от
[ConditionsUIContext](T_Tessa_Extensions_Platform_Client_UI_ConditionsUIContext.htm))  
##  __См. также
#### Ссылки
[NotificationSettingsUIContext -
](T_Tessa_Extensions_Platform_Client_UI_NotificationSettingsUIContext.htm)
[Tessa.Extensions.Platform.Client.UI - пространство
имён](N_Tessa_Extensions_Platform_Client_UI.htm)
