# DeletedOriginalTileExtension - конструктор
Инициализирует новый экземпляр класса
[DeletedOriginalTileExtension](T_Tessa_Extensions_Platform_Client_Tiles_DeletedOriginalTileExtension.htm)
##  __Definition
 **Пространство имён:**
[Tessa.Extensions.Platform.Client.Tiles](N_Tessa_Extensions_Platform_Client_Tiles.htm)  
 **Сборка:** Tessa.UI (в Tessa.UI.dll) Версия: 3.6.0.17
C# __Копировать
     public DeletedOriginalTileExtension(
    	IUIHost uiHost
    )
VB __Копировать
     Public Sub New ( 
    	uiHost As IUIHost
    )
C++ __Копировать
     public:
    DeletedOriginalTileExtension(
    	IUIHost^ uiHost
    )
F# __Копировать
     new : 
            uiHost : IUIHost -> DeletedOriginalTileExtension
#### Параметры
uiHost [IUIHost](T_Tessa_UI_IUIHost.htm)
## __См. также
#### Ссылки
[DeletedOriginalTileExtension -
](T_Tessa_Extensions_Platform_Client_Tiles_DeletedOriginalTileExtension.htm)
[Tessa.Extensions.Platform.Client.Tiles - пространство
имён](N_Tessa_Extensions_Platform_Client_Tiles.htm)
