# IKrVirtualFileScript - интерфейс
Объект со скриптами виртуального файла
## __Definition
 **Пространство имён:**
[Tessa.Extensions.Default.Server.Files.VirtualFiles.Compilation](N_Tessa_Extensions_Default_Server_Files_VirtualFiles_Compilation.htm)  
 **Сборка:** Tessa.Extensions.Default.Server (в
Tessa.Extensions.Default.Server.dll) Версия: 3.6.0.17
C# __Копировать
     public interface IKrVirtualFileScript
VB __Копировать
     Public Interface IKrVirtualFileScript
C++ __Копировать
     public interface class IKrVirtualFileScript
F# __Копировать
     type IKrVirtualFileScript = interface end
##  __Методы
[InitializationScenarioAsync](M_Tessa_Extensions_Default_Server_Files_VirtualFiles_Compilation_IKrVirtualFileScript_InitializationScenarioAsync.htm)|
Скрипт инициализации виртуального файла  
---|---  
## __См. также
#### Ссылки
[Tessa.Extensions.Default.Server.Files.VirtualFiles.Compilation - пространство
имён](N_Tessa_Extensions_Default_Server_Files_VirtualFiles_Compilation.htm)
