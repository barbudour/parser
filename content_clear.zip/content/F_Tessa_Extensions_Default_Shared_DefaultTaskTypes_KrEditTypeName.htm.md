# DefaultTaskTypes.KrEditTypeName - поле
Task type name for "KrEdit".
## __Definition
 **Пространство имён:**
[Tessa.Extensions.Default.Shared](N_Tessa_Extensions_Default_Shared.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17
C# __Копировать
     public const string KrEditTypeName = "KrEdit"
VB __Копировать
     Public Const KrEditTypeName As String = "KrEdit"
C++ __Копировать
     public:
    literal String^ KrEditTypeName = "KrEdit"
F# __Копировать
     static val mutable KrEditTypeName: string
#### Значение поля
[String](https://learn.microsoft.com/dotnet/api/system.string)
##  __См. также
#### Ссылки
[DefaultTaskTypes - ](T_Tessa_Extensions_Default_Shared_DefaultTaskTypes.htm)
[Tessa.Extensions.Default.Shared - пространство
имён](N_Tessa_Extensions_Default_Shared.htm)
