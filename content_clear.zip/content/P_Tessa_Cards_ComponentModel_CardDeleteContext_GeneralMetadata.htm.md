# CardDeleteContext.GeneralMetadata - свойство
Метаинформация по типам карточек.
## __Definition
 **Пространство имён:**
[Tessa.Cards.ComponentModel](N_Tessa_Cards_ComponentModel.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17
C# __Копировать
     public ICardMetadata GeneralMetadata { get; }
VB __Копировать
     Public ReadOnly Property GeneralMetadata As ICardMetadata
    	Get
C++ __Копировать
     public:
    property ICardMetadata^ GeneralMetadata {
    	ICardMetadata^ get ();
    }
F# __Копировать
     member GeneralMetadata : ICardMetadata with get
#### Значение свойства
[ICardMetadata](T_Tessa_Cards_ICardMetadata.htm)
##  __См. также
#### Ссылки
[CardDeleteContext - ](T_Tessa_Cards_ComponentModel_CardDeleteContext.htm)
[Tessa.Cards.ComponentModel - пространство
имён](N_Tessa_Cards_ComponentModel.htm)
