# CardTypeControl.TabTypeCode - поле
Код для типа [CardTypeTabControl](T_Tessa_Cards_CardTypeTabControl.htm),
являющегося наследником для
[CardTypeControl](T_Tessa_Cards_CardTypeControl.htm).
## __Definition
 **Пространство имён:** [Tessa.Cards](N_Tessa_Cards.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17
C# __Копировать
     public const byte TabTypeCode = 2
VB __Копировать
     Public Const TabTypeCode As Byte = 2
C++ __Копировать
     public:
    literal unsigned char TabTypeCode = 2
F# __Копировать
     static val mutable TabTypeCode: byte
#### Значение поля
[Byte](https://learn.microsoft.com/dotnet/api/system.byte)
##  __См. также
#### Ссылки
[CardTypeControl - ](T_Tessa_Cards_CardTypeControl.htm)
[Tessa.Cards - пространство имён](N_Tessa_Cards.htm)
