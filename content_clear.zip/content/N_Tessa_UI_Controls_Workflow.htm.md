# Tessa.UI.Controls.Workflow - пространство имён
Элементы управления для конструктора бизнес-процессов.
##  __Классы
[CardBindingEditorView](T_Tessa_UI_Controls_Workflow_CardBindingEditorView.htm)|
Interaction logic for CardBindingEditorView.xaml  
---|---  
[CardBindingEditorViewModel](T_Tessa_UI_Controls_Workflow_CardBindingEditorViewModel.htm)|  
[CardBindingEditorViewModel.CardTypeItem](T_Tessa_UI_Controls_Workflow_CardBindingEditorViewModel_CardTypeItem.htm)|  
[HashBindingEditorView](T_Tessa_UI_Controls_Workflow_HashBindingEditorView.htm)|
Interaction logic for HashBindingEditorView.xaml  
[HashBindingEditorViewModel](T_Tessa_UI_Controls_Workflow_HashBindingEditorViewModel.htm)|  
[SqlBindingEditorView](T_Tessa_UI_Controls_Workflow_SqlBindingEditorView.htm)|
Interaction logic for SqlBindingEditorView.xaml  
[SqlBindingEditorViewModel](T_Tessa_UI_Controls_Workflow_SqlBindingEditorViewModel.htm)|  
[TaskBindingEditorView](T_Tessa_UI_Controls_Workflow_TaskBindingEditorView.htm)|
Interaction logic for TaskBindingEditorView.xaml  
[TaskBindingEditorViewModel](T_Tessa_UI_Controls_Workflow_TaskBindingEditorViewModel.htm)|  
[ViewBindingEditorView](T_Tessa_UI_Controls_Workflow_ViewBindingEditorView.htm)|
Interaction logic for ViewBindingEditorView.xaml  
[ViewBindingEditorViewModel](T_Tessa_UI_Controls_Workflow_ViewBindingEditorViewModel.htm)|
