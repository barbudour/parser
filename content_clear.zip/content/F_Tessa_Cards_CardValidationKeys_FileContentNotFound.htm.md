# CardValidationKeys.FileContentNotFound - поле
Невозможно загрузить контент файла, т.к. он не найден.
## __Definition
 **Пространство имён:** [Tessa.Cards](N_Tessa_Cards.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17
C# __Копировать
     public static readonly ValidationKey FileContentNotFound
VB __Копировать
     Public Shared ReadOnly FileContentNotFound As ValidationKey
C++ __Копировать
     public:
    static initonly ValidationKey^ FileContentNotFound
F# __Копировать
     static val FileContentNotFound: ValidationKey
#### Значение поля
[ValidationKey](T_Tessa_Platform_Validation_ValidationKey.htm)
##  __См. также
#### Ссылки
[CardValidationKeys - ](T_Tessa_Cards_CardValidationKeys.htm)
[Tessa.Cards - пространство имён](N_Tessa_Cards.htm)
