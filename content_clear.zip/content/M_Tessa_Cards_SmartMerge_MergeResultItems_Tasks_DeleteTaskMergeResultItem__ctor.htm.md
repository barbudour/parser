# DeleteTaskMergeResultItem - конструктор
Инициализирует новый экземпляр класса
[DeleteTaskMergeResultItem](T_Tessa_Cards_SmartMerge_MergeResultItems_Tasks_DeleteTaskMergeResultItem.htm)
##  __Definition
 **Пространство имён:**
[Tessa.Cards.SmartMerge.MergeResultItems.Tasks](N_Tessa_Cards_SmartMerge_MergeResultItems_Tasks.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17
C# __Копировать
     public DeleteTaskMergeResultItem(
    	CardTask task
    )
VB __Копировать
     Public Sub New ( 
    	task As CardTask
    )
C++ __Копировать
     public:
    DeleteTaskMergeResultItem(
    	CardTask^ task
    )
F# __Копировать
     new : 
            task : CardTask -> DeleteTaskMergeResultItem
#### Параметры
task [CardTask](T_Tessa_Cards_CardTask.htm)
## __См. также
#### Ссылки
[DeleteTaskMergeResultItem -
](T_Tessa_Cards_SmartMerge_MergeResultItems_Tasks_DeleteTaskMergeResultItem.htm)
[Tessa.Cards.SmartMerge.MergeResultItems.Tasks - пространство
имён](N_Tessa_Cards_SmartMerge_MergeResultItems_Tasks.htm)
