# Tessa.Extensions.Default.Console.ConvertConfiguration - пространство имён
## __Классы
[Command](T_Tessa_Extensions_Default_Console_ConvertConfiguration_Command.htm)|  
---|---  
[CommandRegistrator](T_Tessa_Extensions_Default_Console_ConvertConfiguration_CommandRegistrator.htm)|  
[Operation](T_Tessa_Extensions_Default_Console_ConvertConfiguration_Operation.htm)|  
[OperationContext](T_Tessa_Extensions_Default_Console_ConvertConfiguration_OperationContext.htm)|  
[OperationRegistrator](T_Tessa_Extensions_Default_Console_ConvertConfiguration_OperationRegistrator.htm)|  
## __Перечисления
[ConversionMode](T_Tessa_Extensions_Default_Console_ConvertConfiguration_ConversionMode.htm)|
Режим преобразования конфигурации.  
---|---
