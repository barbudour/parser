# Card.TypeIDKey - поле
##  __Definition
 **Пространство имён:** [Tessa.Cards](N_Tessa_Cards.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17
C# __Копировать
     public const string TypeIDKey = "TypeID"
VB __Копировать
     Public Const TypeIDKey As String = "TypeID"
C++ __Копировать
     public:
    literal String^ TypeIDKey = "TypeID"
F# __Копировать
     static val mutable TypeIDKey: string
#### Значение поля
[String](https://learn.microsoft.com/dotnet/api/system.string)
##  __См. также
#### Ссылки
[Card - ](T_Tessa_Cards_Card.htm)
[Tessa.Cards - пространство имён](N_Tessa_Cards.htm)
