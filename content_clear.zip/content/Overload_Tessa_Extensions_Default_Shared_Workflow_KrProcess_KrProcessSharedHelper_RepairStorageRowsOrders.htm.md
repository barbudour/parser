# KrProcessSharedHelper.RepairStorageRowsOrders - метод
##  __Список перегрузок
[RepairStorageRowsOrders(IList,
String)](M_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrProcessSharedHelper_RepairStorageRowsOrders.htm)|
Восстанавливает порядок сортировки для списка строк.  
---|---  
[RepairStorageRowsOrders(IList, String,
String)](M_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrProcessSharedHelper_RepairStorageRowsOrders_1.htm)|
Восстанавливает порядок сортировки для списка строк.  
## __См. также
#### Ссылки
[KrProcessSharedHelper -
](T_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrProcessSharedHelper.htm)
[Tessa.Extensions.Default.Shared.Workflow.KrProcess - пространство
имён](N_Tessa_Extensions_Default_Shared_Workflow_KrProcess.htm)
