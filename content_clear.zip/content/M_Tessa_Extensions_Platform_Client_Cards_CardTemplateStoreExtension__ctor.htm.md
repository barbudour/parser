# CardTemplateStoreExtension - конструктор
Инициализирует новый экземпляр класса
[CardTemplateStoreExtension](T_Tessa_Extensions_Platform_Client_Cards_CardTemplateStoreExtension.htm)
##  __Definition
 **Пространство имён:**
[Tessa.Extensions.Platform.Client.Cards](N_Tessa_Extensions_Platform_Client_Cards.htm)  
 **Сборка:** Tessa.UI (в Tessa.UI.dll) Версия: 3.6.0.17
C# __Копировать
     public CardTemplateStoreExtension(
    	ICardManager cardManager
    )
VB __Копировать
     Public Sub New ( 
    	cardManager As ICardManager
    )
C++ __Копировать
     public:
    CardTemplateStoreExtension(
    	ICardManager^ cardManager
    )
F# __Копировать
     new : 
            cardManager : ICardManager -> CardTemplateStoreExtension
#### Параметры
cardManager [ICardManager](T_Tessa_Cards_ICardManager.htm)
## __См. также
#### Ссылки
[CardTemplateStoreExtension -
](T_Tessa_Extensions_Platform_Client_Cards_CardTemplateStoreExtension.htm)
[Tessa.Extensions.Platform.Client.Cards - пространство
имён](N_Tessa_Extensions_Platform_Client_Cards.htm)
