# IExtraSource.DisplayName - свойство
Отображаемое имя метода.
## __Definition
 **Пространство имён:**
[Tessa.Extensions.Default.Shared.Workflow.KrCompilers](N_Tessa_Extensions_Default_Shared_Workflow_KrCompilers.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17
C# __Копировать
     string DisplayName { get; }
VB __Копировать
     ReadOnly Property DisplayName As String
    	Get
C++ __Копировать
    property String^ DisplayName {
    	String^ get ();
    }
F# __Копировать
     abstract DisplayName : string with get
#### Значение свойства
[String](https://learn.microsoft.com/dotnet/api/system.string)
##  __См. также
#### Ссылки
[IExtraSource -
](T_Tessa_Extensions_Default_Shared_Workflow_KrCompilers_IExtraSource.htm)
[Tessa.Extensions.Default.Shared.Workflow.KrCompilers - пространство
имён](N_Tessa_Extensions_Default_Shared_Workflow_KrCompilers.htm)
