# CardControlTypes.Numerator - поле
Numerator для работы с номером.
## __Definition
 **Пространство имён:** [Tessa.Cards](N_Tessa_Cards.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17
C# __Копировать
     public static readonly CardControlType Numerator
VB __Копировать
     Public Shared ReadOnly Numerator As CardControlType
C++ __Копировать
     public:
    static initonly CardControlType^ Numerator
F# __Копировать
     static val Numerator: CardControlType
#### Значение поля
[CardControlType](T_Tessa_Cards_CardControlType.htm)
##  __См. также
#### Ссылки
[CardControlTypes - ](T_Tessa_Cards_CardControlTypes.htm)
[Tessa.Cards - пространство имён](N_Tessa_Cards.htm)
