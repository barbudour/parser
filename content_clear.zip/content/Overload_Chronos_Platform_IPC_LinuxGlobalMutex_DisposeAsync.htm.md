# LinuxGlobalMutex.DisposeAsync - метод
##  __Список перегрузок
[DisposeAsync()](M_Chronos_Platform_IPC_GlobalMutexBase_DisposeAsync.htm)|
Освобождает ресурсы, занимаемые объектом.  
---|---  
[DisposeAsync(Boolean)](M_Chronos_Platform_IPC_LinuxGlobalMutex_DisposeAsync.htm)|
Освобождает ресурсы, занимаемые объектом.  
##  __См. также
#### Ссылки
[LinuxGlobalMutex - ](T_Chronos_Platform_IPC_LinuxGlobalMutex.htm)
[Chronos.Platform.IPC - пространство имён](N_Chronos_Platform_IPC.htm)
