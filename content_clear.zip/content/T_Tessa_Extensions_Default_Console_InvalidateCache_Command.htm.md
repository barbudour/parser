# Command - класс
##  __Definition
 **Пространство имён:**
[Tessa.Extensions.Default.Console.InvalidateCache](N_Tessa_Extensions_Default_Console_InvalidateCache.htm)  
 **Сборка:** Tessa.Extensions.Default.Console (в
Tessa.Extensions.Default.Console.dll) Версия: 3.6.0.17
C# __Копировать
     public static class Command
VB __Копировать
     Public NotInheritable Class Command
C++ __Копировать
     public ref class Command abstract sealed
F# __Копировать
     [<AbstractClassAttribute>]
    [<SealedAttribute>]
    type Command = class end
Inheritance
    [Object](https://learn.microsoft.com/dotnet/api/system.object) __ Command
##  __Методы
[InvalidateCache](M_Tessa_Extensions_Default_Console_InvalidateCache_Command_InvalidateCache.htm)|  
---|---  
## __См. также
#### Ссылки
[Tessa.Extensions.Default.Console.InvalidateCache - пространство
имён](N_Tessa_Extensions_Default_Console_InvalidateCache.htm)
