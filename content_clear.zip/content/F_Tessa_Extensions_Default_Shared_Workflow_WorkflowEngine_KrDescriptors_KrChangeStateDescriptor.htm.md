# KrDescriptors.KrChangeStateDescriptor - поле
##  __Definition
 **Пространство имён:**
[Tessa.Extensions.Default.Shared.Workflow.WorkflowEngine](N_Tessa_Extensions_Default_Shared_Workflow_WorkflowEngine.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17
C# __Копировать
     public static readonly WorkflowActionDescriptor KrChangeStateDescriptor
VB __Копировать
     Public Shared ReadOnly KrChangeStateDescriptor As WorkflowActionDescriptor
C++ __Копировать
     public:
    static initonly WorkflowActionDescriptor^ KrChangeStateDescriptor
F# __Копировать
     static val KrChangeStateDescriptor: WorkflowActionDescriptor
#### Значение поля
[WorkflowActionDescriptor](T_Tessa_Workflow_Actions_Descriptors_WorkflowActionDescriptor.htm)
##  __См. также
#### Ссылки
[KrDescriptors -
](T_Tessa_Extensions_Default_Shared_Workflow_WorkflowEngine_KrDescriptors.htm)
[Tessa.Extensions.Default.Shared.Workflow.WorkflowEngine - пространство
имён](N_Tessa_Extensions_Default_Shared_Workflow_WorkflowEngine.htm)
