# FakeWorkplaceService - конструктор
Инициализирует новый экземпляр класса
[FakeWorkplaceService](T_Tessa_Applications_FakeWorkplaceService.htm)
##  __Definition
 **Пространство имён:** [Tessa.Applications](N_Tessa_Applications.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17
C# __Копировать
     public FakeWorkplaceService()
VB __Копировать
     Public Sub New
C++ __Копировать
     public:
    FakeWorkplaceService()
F# __Копировать
     new : unit -> FakeWorkplaceService
##  __См. также
#### Ссылки
[FakeWorkplaceService - ](T_Tessa_Applications_FakeWorkplaceService.htm)
[Tessa.Applications - пространство имён](N_Tessa_Applications.htm)
