# CardTask.AuthorPositionKey - поле
##  __Definition
 **Пространство имён:** [Tessa.Cards](N_Tessa_Cards.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17
C# __Копировать
     public const string AuthorPositionKey = "AuthorPosition"
VB __Копировать
     Public Const AuthorPositionKey As String = "AuthorPosition"
C++ __Копировать
     public:
    literal String^ AuthorPositionKey = "AuthorPosition"
F# __Копировать
     static val mutable AuthorPositionKey: string
#### Значение поля
[String](https://learn.microsoft.com/dotnet/api/system.string)
##  __См. также
#### Ссылки
[CardTask - ](T_Tessa_Cards_CardTask.htm)
[Tessa.Cards - пространство имён](N_Tessa_Cards.htm)
