# IKrPermissionSectionSettings.MaskedFields - свойство
##  __Definition
 **Пространство имён:**
[Tessa.Extensions.Default.Shared.Workflow.KrPermissions](N_Tessa_Extensions_Default_Shared_Workflow_KrPermissions.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17
C# __Копировать
    IReadOnlyCollection<Guid> MaskedFields { get; set; }
VB __Копировать
     Property MaskedFields As IReadOnlyCollection(Of Guid)
    	Get
    	Set
C++ __Копировать
    property IReadOnlyCollection<Guid>^ MaskedFields {
    	IReadOnlyCollection<Guid>^ get ();
    	void set (IReadOnlyCollection<Guid>^ value);
    }
F# __Копировать
     abstract MaskedFields : IReadOnlyCollection<Guid> with get, set
#### Значение свойства
[IReadOnlyCollection](https://learn.microsoft.com/dotnet/api/system.collections.generic.ireadonlycollection-1)<[Guid](https://learn.microsoft.com/dotnet/api/system.guid)>
##  __См. также
#### Ссылки
[IKrPermissionSectionSettings -
](T_Tessa_Extensions_Default_Shared_Workflow_KrPermissions_IKrPermissionSectionSettings.htm)
[Tessa.Extensions.Default.Shared.Workflow.KrPermissions - пространство
имён](N_Tessa_Extensions_Default_Shared_Workflow_KrPermissions.htm)
