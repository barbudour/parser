# DefaultRegulateStrategy.Instance - свойство
Экземпляр класса.
##  __Definition
 **Пространство имён:** [Tessa.Extensions](N_Tessa_Extensions.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17
C# __Копировать
     public static DefaultRegulateStrategy Instance { get; }
VB __Копировать
     Public Shared ReadOnly Property Instance As DefaultRegulateStrategy
    	Get
C++ __Копировать
     public:
    static property DefaultRegulateStrategy^ Instance {
    	DefaultRegulateStrategy^ get ();
    }
F# __Копировать
     static member Instance : DefaultRegulateStrategy with get
#### Значение свойства
[DefaultRegulateStrategy](T_Tessa_Extensions_DefaultRegulateStrategy.htm)
##  __См. также
#### Ссылки
[DefaultRegulateStrategy - ](T_Tessa_Extensions_DefaultRegulateStrategy.htm)
[Tessa.Extensions - пространство имён](N_Tessa_Extensions.htm)
