# CustomNotification.Email - свойство
##  __Definition
 **Пространство имён:**
[Tessa.Extensions.Default.Shared.Notices](N_Tessa_Extensions_Default_Shared_Notices.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17
C# __Копировать
     public string Email { get; }
VB __Копировать
     Public ReadOnly Property Email As String
    	Get
C++ __Копировать
     public:
    property String^ Email {
    	String^ get ();
    }
F# __Копировать
     member Email : string with get
#### Значение свойства
[String](https://learn.microsoft.com/dotnet/api/system.string)
##  __См. также
#### Ссылки
[CustomNotification -
](T_Tessa_Extensions_Default_Shared_Notices_CustomNotification.htm)
[Tessa.Extensions.Default.Shared.Notices - пространство
имён](N_Tessa_Extensions_Default_Shared_Notices.htm)
