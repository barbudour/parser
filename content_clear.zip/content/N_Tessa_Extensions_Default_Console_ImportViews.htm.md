# Tessa.Extensions.Default.Console.ImportViews - пространство имён
## __Классы
[Command](T_Tessa_Extensions_Default_Console_ImportViews_Command.htm)|  
---|---  
[CommandRegistrator](T_Tessa_Extensions_Default_Console_ImportViews_CommandRegistrator.htm)|  
[Operation](T_Tessa_Extensions_Default_Console_ImportViews_Operation.htm)|
Операция импорта представлений  
[OperationContext](T_Tessa_Extensions_Default_Console_ImportViews_OperationContext.htm)|
Контекст операции импорта представлений  
[OperationRegistrator](T_Tessa_Extensions_Default_Console_ImportViews_OperationRegistrator.htm)|
