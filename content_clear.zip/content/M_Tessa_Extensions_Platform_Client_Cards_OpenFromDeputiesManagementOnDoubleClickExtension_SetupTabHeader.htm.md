# OpenFromDeputiesManagementOnDoubleClickExtension.SetupTabHeader - метод
##  __Definition
 **Пространство имён:**
[Tessa.Extensions.Platform.Client.Cards](N_Tessa_Extensions_Platform_Client_Cards.htm)  
 **Сборка:** Tessa.UI (в Tessa.UI.dll) Версия: 3.6.0.17
C# __Копировать
     public static void SetupTabHeader(
    	IUIContextObject uiObject
    )
VB __Копировать
     Public Shared Sub SetupTabHeader ( 
    	uiObject As IUIContextObject
    )
C++ __Копировать
     public:
    static void SetupTabHeader(
    	IUIContextObject^ uiObject
    )
F# __Копировать
     static member SetupTabHeader : 
            uiObject : IUIContextObject -> unit 
#### Параметры
uiObject [IUIContextObject](T_Tessa_UI_IUIContextObject.htm)
## __См. также
#### Ссылки
[OpenFromDeputiesManagementOnDoubleClickExtension -
](T_Tessa_Extensions_Platform_Client_Cards_OpenFromDeputiesManagementOnDoubleClickExtension.htm)
[Tessa.Extensions.Platform.Client.Cards - пространство
имён](N_Tessa_Extensions_Platform_Client_Cards.htm)
