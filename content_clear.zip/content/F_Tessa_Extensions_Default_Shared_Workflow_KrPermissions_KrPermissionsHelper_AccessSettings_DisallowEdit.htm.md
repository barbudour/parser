# KrPermissionsHelper.AccessSettings.DisallowEdit - поле
##  __Definition
 **Пространство имён:**
[Tessa.Extensions.Default.Shared.Workflow.KrPermissions](N_Tessa_Extensions_Default_Shared_Workflow_KrPermissions.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17
C# __Копировать
     public const int DisallowEdit = 1
VB __Копировать
     Public Const DisallowEdit As Integer = 1
C++ __Копировать
     public:
    literal int DisallowEdit = 1
F# __Копировать
     static val mutable DisallowEdit: int
#### Значение поля
[Int32](https://learn.microsoft.com/dotnet/api/system.int32)
##  __См. также
#### Ссылки
[KrPermissionsHelper.AccessSettings -
](T_Tessa_Extensions_Default_Shared_Workflow_KrPermissions_KrPermissionsHelper_AccessSettings.htm)
[Tessa.Extensions.Default.Shared.Workflow.KrPermissions - пространство
имён](N_Tessa_Extensions_Default_Shared_Workflow_KrPermissions.htm)
