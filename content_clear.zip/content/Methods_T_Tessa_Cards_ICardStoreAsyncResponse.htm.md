# ICardStoreAsyncResponse - методы
##  __Методы
[ConfigureAwait](M_Tessa_Cards_ICardStoreAsyncResponse_ConfigureAwait.htm)|
Настраивает ожидание задачи.  
---|---  
[GetAwaiter](M_Tessa_Cards_ICardStoreAsyncResponse_GetAwaiter.htm)|
Возвращает объект, выполняющий ожидание результата задачи
[ICardStoreAsyncResponse.Task].  
## __См. также
#### Ссылки
[ICardStoreAsyncResponse - ](T_Tessa_Cards_ICardStoreAsyncResponse.htm)
[Tessa.Cards - пространство имён](N_Tessa_Cards.htm)
