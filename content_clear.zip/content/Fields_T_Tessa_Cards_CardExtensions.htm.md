# CardExtensions - поля
##  __Поля
[ApplyUserSettingsRoleIDListKey](F_Tessa_Cards_CardExtensions_ApplyUserSettingsRoleIDListKey.htm)|  
---|---  
[ApplyUserSettingsUserIDKey](F_Tessa_Cards_CardExtensions_ApplyUserSettingsUserIDKey.htm)|  
## __См. также
#### Ссылки
[CardExtensions - ](T_Tessa_Cards_CardExtensions.htm)
[Tessa.Cards - пространство имён](N_Tessa_Cards.htm)
