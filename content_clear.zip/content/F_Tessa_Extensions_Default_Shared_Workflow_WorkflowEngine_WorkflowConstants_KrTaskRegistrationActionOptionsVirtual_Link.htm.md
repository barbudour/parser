# WorkflowConstants.KrTaskRegistrationActionOptionsVirtual.Link - поле
##  __Definition
 **Пространство имён:**
[Tessa.Extensions.Default.Shared.Workflow.WorkflowEngine](N_Tessa_Extensions_Default_Shared_Workflow_WorkflowEngine.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17
C# __Копировать
     public const string Link = "Link"
VB __Копировать
     Public Const Link As String = "Link"
C++ __Копировать
     public:
    literal String^ Link = "Link"
F# __Копировать
     static val mutable Link: string
#### Значение поля
[String](https://learn.microsoft.com/dotnet/api/system.string)
##  __См. также
#### Ссылки
[WorkflowConstants.KrTaskRegistrationActionOptionsVirtual -
](T_Tessa_Extensions_Default_Shared_Workflow_WorkflowEngine_WorkflowConstants_KrTaskRegistrationActionOptionsVirtual.htm)
[Tessa.Extensions.Default.Shared.Workflow.WorkflowEngine - пространство
имён](N_Tessa_Extensions_Default_Shared_Workflow_WorkflowEngine.htm)
