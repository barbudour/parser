# WebChartLegendPosition - перечисление
##  __Definition
 **Пространство имён:**
[Tessa.Extensions.Default.Shared.Workplaces](N_Tessa_Extensions_Default_Shared_Workplaces.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17
C# __Копировать
     public enum WebChartLegendPosition
VB __Копировать
     Public Enumeration WebChartLegendPosition
C++ __Копировать
     public enum class WebChartLegendPosition
F# __Копировать
     type WebChartLegendPosition
##  __Члены
None| 1|  
---|---|---  
Bottom| 2|  
Left| 3|  
Right| 4|  
Top| 5|  
## __См. также
#### Ссылки
[Tessa.Extensions.Default.Shared.Workplaces - пространство
имён](N_Tessa_Extensions_Default_Shared_Workplaces.htm)
