# KrConstants.KrStages.NestedOrder - поле
##  __Definition
 **Пространство имён:**
[Tessa.Extensions.Default.Shared.Workflow.KrProcess](N_Tessa_Extensions_Default_Shared_Workflow_KrProcess.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17
C# __Копировать
     public const string NestedOrder = "NestedOrder"
VB __Копировать
     Public Const NestedOrder As String = "NestedOrder"
C++ __Копировать
     public:
    literal String^ NestedOrder = "NestedOrder"
F# __Копировать
     static val mutable NestedOrder: string
#### Значение поля
[String](https://learn.microsoft.com/dotnet/api/system.string)
##  __См. также
#### Ссылки
[KrConstants.KrStages -
](T_Tessa_Extensions_Default_Shared_Workflow_KrProcess_KrConstants_KrStages.htm)
[Tessa.Extensions.Default.Shared.Workflow.KrProcess - пространство
имён](N_Tessa_Extensions_Default_Shared_Workflow_KrProcess.htm)
