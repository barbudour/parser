# Command - класс
##  __Definition
 **Пространство имён:**
[Tessa.Extensions.Default.Console.ExportSchemeSql](N_Tessa_Extensions_Default_Console_ExportSchemeSql.htm)  
 **Сборка:** Tessa.Extensions.Default.Console (в
Tessa.Extensions.Default.Console.dll) Версия: 3.6.0.17
C# __Копировать
     public static class Command
VB __Копировать
     Public NotInheritable Class Command
C++ __Копировать
     public ref class Command abstract sealed
F# __Копировать
     [<AbstractClassAttribute>]
    [<SealedAttribute>]
    type Command = class end
Inheritance
    [Object](https://learn.microsoft.com/dotnet/api/system.object) __ Command
##  __Методы
[ExportSchemeSql](M_Tessa_Extensions_Default_Console_ExportSchemeSql_Command_ExportSchemeSql.htm)|  
---|---  
## __См. также
#### Ссылки
[Tessa.Extensions.Default.Console.ExportSchemeSql - пространство
имён](N_Tessa_Extensions_Default_Console_ExportSchemeSql.htm)
