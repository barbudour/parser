# CardLockingStrategy.LockedByReadersCode - поле
Результат выполнения хранимой процедуры ObtainWriterLock в случае, если writer
не дождался окончания чтения другими reader'ами.
## __Definition
 **Пространство имён:** [Tessa.Cards](N_Tessa_Cards.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17
C# __Копировать
     protected const int LockedByReadersCode = 2
VB __Копировать
     Protected Const LockedByReadersCode As Integer = 2
C++ __Копировать
     protected:
    literal int LockedByReadersCode = 2
F# __Копировать
     static val mutable LockedByReadersCode: int
#### Значение поля
[Int32](https://learn.microsoft.com/dotnet/api/system.int32)
##  __См. также
#### Ссылки
[CardLockingStrategy - ](T_Tessa_Cards_CardLockingStrategy.htm)
[Tessa.Cards - пространство имён](N_Tessa_Cards.htm)
