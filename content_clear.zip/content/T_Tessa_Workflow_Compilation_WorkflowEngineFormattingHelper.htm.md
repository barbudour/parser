# WorkflowEngineFormattingHelper - класс
##  __Definition
 **Пространство имён:**
[Tessa.Workflow.Compilation](N_Tessa_Workflow_Compilation.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17
C# __Копировать
     public static class WorkflowEngineFormattingHelper
VB __Копировать
     Public NotInheritable Class WorkflowEngineFormattingHelper
C++ __Копировать
     public ref class WorkflowEngineFormattingHelper abstract sealed
F# __Копировать
     [<AbstractClassAttribute>]
    [<SealedAttribute>]
    type WorkflowEngineFormattingHelper = class end
Inheritance
    [Object](https://learn.microsoft.com/dotnet/api/system.object) __ WorkflowEngineFormattingHelper
##  __Методы
[IndentText](M_Tessa_Workflow_Compilation_WorkflowEngineFormattingHelper_IndentText.htm)|  
---|---  
[PrepareGlobalScript](M_Tessa_Workflow_Compilation_WorkflowEngineFormattingHelper_PrepareGlobalScript.htm)|  
[PrepareScenario](M_Tessa_Workflow_Compilation_WorkflowEngineFormattingHelper_PrepareScenario.htm)|  
## __См. также
#### Ссылки
[Tessa.Workflow.Compilation - пространство
имён](N_Tessa_Workflow_Compilation.htm)
