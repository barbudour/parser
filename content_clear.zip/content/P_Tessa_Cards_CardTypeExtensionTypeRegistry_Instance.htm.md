# CardTypeExtensionTypeRegistry.Instance - свойство
Экземпляр класса.
##  __Definition
 **Пространство имён:** [Tessa.Cards](N_Tessa_Cards.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17
C# __Копировать
     public static ICardTypeExtensionTypeRegistry Instance { get; }
VB __Копировать
     Public Shared ReadOnly Property Instance As ICardTypeExtensionTypeRegistry
    	Get
C++ __Копировать
     public:
    static property ICardTypeExtensionTypeRegistry^ Instance {
    	ICardTypeExtensionTypeRegistry^ get ();
    }
F# __Копировать
     static member Instance : ICardTypeExtensionTypeRegistry with get
#### Значение свойства
[ICardTypeExtensionTypeRegistry](T_Tessa_Cards_ICardTypeExtensionTypeRegistry.htm)
##  __См. также
#### Ссылки
[CardTypeExtensionTypeRegistry -
](T_Tessa_Cards_CardTypeExtensionTypeRegistry.htm)
[Tessa.Cards - пространство имён](N_Tessa_Cards.htm)
