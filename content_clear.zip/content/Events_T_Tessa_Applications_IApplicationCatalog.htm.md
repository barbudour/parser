# IApplicationCatalog - события
##  __События
[PropertyChanged](https://learn.microsoft.com/dotnet/api/system.componentmodel.inotifypropertychanged.propertychanged)|
Occurs when a property value changes.  
(Унаследован от
[INotifyPropertyChanged](https://learn.microsoft.com/dotnet/api/system.componentmodel.inotifypropertychanged))  
---|---  
##  __См. также
#### Ссылки
[IApplicationCatalog - ](T_Tessa_Applications_IApplicationCatalog.htm)
[Tessa.Applications - пространство имён](N_Tessa_Applications.htm)
