# CardTaskCompletionOptionSettings.CardNewMethod - свойство
Возвращает или задаёт значение, задающее способ создания карточки диалога.
## __Definition
 **Пространство имён:** [Tessa.Cards](N_Tessa_Cards.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17
C# __Копировать
     public CardTaskDialogNewMethod CardNewMethod { get; set; }
VB __Копировать
     Public Property CardNewMethod As CardTaskDialogNewMethod
    	Get
    	Set
C++ __Копировать
     public:
    property CardTaskDialogNewMethod CardNewMethod {
    	CardTaskDialogNewMethod get ();
    	void set (CardTaskDialogNewMethod value);
    }
F# __Копировать
     member CardNewMethod : CardTaskDialogNewMethod with get, set
#### Значение свойства
[CardTaskDialogNewMethod](T_Tessa_Cards_CardTaskDialogNewMethod.htm)
##  __См. также
#### Ссылки
[CardTaskCompletionOptionSettings -
](T_Tessa_Cards_CardTaskCompletionOptionSettings.htm)
[Tessa.Cards - пространство имён](N_Tessa_Cards.htm)
