# CardMetadataRecord - конструктор
Создаёт экземпляр класса с параметрами по умолчанию.
##  __Definition
 **Пространство имён:** [Tessa.Cards.Metadata](N_Tessa_Cards_Metadata.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17
C# __Копировать
     public CardMetadataRecord()
VB __Копировать
     Public Sub New
C++ __Копировать
     public:
    CardMetadataRecord()
F# __Копировать
     new : unit -> CardMetadataRecord
##  __См. также
#### Ссылки
[CardMetadataRecord - ](T_Tessa_Cards_Metadata_CardMetadataRecord.htm)
[Tessa.Cards.Metadata - пространство имён](N_Tessa_Cards_Metadata.htm)
