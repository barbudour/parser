# NumberQueueItem.QueueEventType - свойство
Тип события по вызову действия с номером, в результате которого была добавлена
запись в очередь [NumberQueue](T_Tessa_Cards_Numbers_NumberQueue.htm).
## __Definition
 **Пространство имён:** [Tessa.Cards.Numbers](N_Tessa_Cards_Numbers.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17
C# __Копировать
     public NumberQueueEventType QueueEventType { get; set; }
VB __Копировать
     Public Property QueueEventType As NumberQueueEventType
    	Get
    	Set
C++ __Копировать
     public:
    property NumberQueueEventType^ QueueEventType {
    	NumberQueueEventType^ get ();
    	void set (NumberQueueEventType^ value);
    }
F# __Копировать
     member QueueEventType : NumberQueueEventType with get, set
#### Значение свойства
[NumberQueueEventType](T_Tessa_Cards_Numbers_NumberQueueEventType.htm)
##  __Заметки
Значение свойства никогда не равно null.
## __См. также
#### Ссылки
[NumberQueueItem - ](T_Tessa_Cards_Numbers_NumberQueueItem.htm)
[Tessa.Cards.Numbers - пространство имён](N_Tessa_Cards_Numbers.htm)
