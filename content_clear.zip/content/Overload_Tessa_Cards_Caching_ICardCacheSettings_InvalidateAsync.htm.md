# ICardCacheSettings.InvalidateAsync - метод
##  __Список перегрузок
[InvalidateAsync(CancellationToken)](M_Tessa_Cards_Caching_ICardCacheSettings_InvalidateAsync_1.htm)|
Очищает кэш, при этом удаляются все настройки.  
---|---  
[InvalidateAsync(String,
CancellationToken)](M_Tessa_Cards_Caching_ICardCacheSettings_InvalidateAsync.htm)|
Выполняет удаление настройки из кэша по заданному ключу.  
## __См. также
#### Ссылки
[ICardCacheSettings - ](T_Tessa_Cards_Caching_ICardCacheSettings.htm)
[Tessa.Cards.Caching - пространство имён](N_Tessa_Cards_Caching.htm)
