# CycleGroupingInfoKeys.MaxCycleNumberKey - поле
##  __Definition
 **Пространство имён:**
[Tessa.Extensions.Default.Shared](N_Tessa_Extensions_Default_Shared.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17
C# __Копировать
     public const string MaxCycleNumberKey = "KrMaxCycleNumber"
VB __Копировать
     Public Const MaxCycleNumberKey As String = "KrMaxCycleNumber"
C++ __Копировать
     public:
    literal String^ MaxCycleNumberKey = "KrMaxCycleNumber"
F# __Копировать
     static val mutable MaxCycleNumberKey: string
#### Значение поля
[String](https://learn.microsoft.com/dotnet/api/system.string)
##  __См. также
#### Ссылки
[CycleGroupingInfoKeys -
](T_Tessa_Extensions_Default_Shared_CycleGroupingInfoKeys.htm)
[Tessa.Extensions.Default.Shared - пространство
имён](N_Tessa_Extensions_Default_Shared.htm)
