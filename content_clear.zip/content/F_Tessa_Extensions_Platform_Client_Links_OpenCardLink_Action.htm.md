# OpenCardLink.Action - поле
##  __Definition
 **Пространство имён:**
[Tessa.Extensions.Platform.Client.Links](N_Tessa_Extensions_Platform_Client_Links.htm)  
 **Сборка:** Tessa.UI (в Tessa.UI.dll) Версия: 3.6.0.17
C# __Копировать
     public const string Action = "OpenCard"
VB __Копировать
     Public Const Action As String = "OpenCard"
C++ __Копировать
     public:
    literal String^ Action = "OpenCard"
F# __Копировать
     static val mutable Action: string
#### Значение поля
[String](https://learn.microsoft.com/dotnet/api/system.string)
##  __См. также
#### Ссылки
[OpenCardLink - ](T_Tessa_Extensions_Platform_Client_Links_OpenCardLink.htm)
[Tessa.Extensions.Platform.Client.Links - пространство
имён](N_Tessa_Extensions_Platform_Client_Links.htm)
