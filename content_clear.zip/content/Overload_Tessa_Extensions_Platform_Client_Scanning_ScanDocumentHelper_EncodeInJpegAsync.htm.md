# ScanDocumentHelper.EncodeInJpegAsync - метод
##  __Список перегрузок
[EncodeInJpegAsync(Stream, String,
Int32)](M_Tessa_Extensions_Platform_Client_Scanning_ScanDocumentHelper_EncodeInJpegAsync.htm)|
Выполняет кодирование изображения любого допустимого формата из потока
sourceStream в формат JPEG, совместимый с PDF.  
---|---  
[EncodeInJpegAsync(String, String,
Int32)](M_Tessa_Extensions_Platform_Client_Scanning_ScanDocumentHelper_EncodeInJpegAsync_1.htm)|
Выполняет кодирование изображения любого допустимого формата из файла
sourceName в формат JPEG, совместимый с PDF.  
## __См. также
#### Ссылки
[ScanDocumentHelper -
](T_Tessa_Extensions_Platform_Client_Scanning_ScanDocumentHelper.htm)
[Tessa.Extensions.Platform.Client.Scanning - пространство
имён](N_Tessa_Extensions_Platform_Client_Scanning.htm)
