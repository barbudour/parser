# Tessa.Forums.ForumCached - пространство имён
## __Классы
[ForumButtonSettings](T_Tessa_Forums_ForumCached_ForumButtonSettings.htm)|  
---|---  
[ForumButtonSettingsCache](T_Tessa_Forums_ForumCached_ForumButtonSettingsCache.htm)|  
[ForumCachedData](T_Tessa_Forums_ForumCached_ForumCachedData.htm)|  
[ForumClientCachedDataManager](T_Tessa_Forums_ForumCached_ForumClientCachedDataManager.htm)|  
[ForumData](T_Tessa_Forums_ForumCached_ForumData.htm)|  
[ForumStreamService](T_Tessa_Forums_ForumCached_ForumStreamService.htm)|  
## __Интерфейсы
[IForumButtonSettingsCache](T_Tessa_Forums_ForumCached_IForumButtonSettingsCache.htm)|
Клиентский кеш, храним настройки летающей кнопки для пользователя  
---|---  
[IForumCachedData](T_Tessa_Forums_ForumCached_IForumCachedData.htm)|  
[IForumClientCachedDataManager](T_Tessa_Forums_ForumCached_IForumClientCachedDataManager.htm)|
Менеджер живет только на клиенте и работает с ранее загруженном форумном кеше  
[IForumData](T_Tessa_Forums_ForumCached_IForumData.htm)|  Информация по
статусу топиков у пользователя.  
[IForumStreamService](T_Tessa_Forums_ForumCached_IForumStreamService.htm)|
