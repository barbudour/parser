# CreatePartnerKeys.MainCardIDKey - поле
##  __Definition
 **Пространство имён:**
[Tessa.Extensions.Default.Shared](N_Tessa_Extensions_Default_Shared.htm)  
 **Сборка:** Tessa.Extensions.Default.Shared (в
Tessa.Extensions.Default.Shared.dll) Версия: 3.6.0.17
C# __Копировать
     public const string MainCardIDKey = ".MainCardID"
VB __Копировать
     Public Const MainCardIDKey As String = ".MainCardID"
C++ __Копировать
     public:
    literal String^ MainCardIDKey = ".MainCardID"
F# __Копировать
     static val mutable MainCardIDKey: string
#### Значение поля
[String](https://learn.microsoft.com/dotnet/api/system.string)
##  __См. также
#### Ссылки
[CreatePartnerKeys -
](T_Tessa_Extensions_Default_Shared_CreatePartnerKeys.htm)
[Tessa.Extensions.Default.Shared - пространство
имён](N_Tessa_Extensions_Default_Shared.htm)
