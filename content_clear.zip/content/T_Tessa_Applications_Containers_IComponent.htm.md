# IComponent - интерфейс
Описание интерфейса компонента системы IComponent
##  __Definition
 **Пространство имён:**
[Tessa.Applications.Containers](N_Tessa_Applications_Containers.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17
C# __Копировать
     public interface IComponent
VB __Копировать
     Public Interface IComponent
C++ __Копировать
     public interface class IComponent
F# __Копировать
     type IComponent = interface end
##  __Свойства
[Parent](P_Tessa_Applications_Containers_IComponent_Parent.htm)|  Gets or sets
Родитель/Владелец  
---|---  
## __Методы
[GetFullyQualifiedName](M_Tessa_Applications_Containers_IComponent_GetFullyQualifiedName.htm)|
Возвращает полное имя объекта  
---|---  
## __См. также
#### Ссылки
[Tessa.Applications.Containers - пространство
имён](N_Tessa_Applications_Containers.htm)
