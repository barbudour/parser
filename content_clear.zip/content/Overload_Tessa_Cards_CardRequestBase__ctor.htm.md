# CardRequestBase - конструктор
##  __Список перегрузок
[CardRequestBase(Dictionary<String,
Object>)](M_Tessa_Cards_CardRequestBase__ctor.htm)| Создаёт экземпляр класса с
указанием хранилища, декоратором для которого является создаваемый объект.  
---|---  
[CardRequestBase(SerializationInfo,
StreamingContext)](M_Tessa_Cards_CardRequestBase__ctor_1.htm)|  Создаёт
экземпляр класса, десериализованный с использованием переданного объекта
[System.Runtime.Serialization.SerializationInfo].  
## __См. также
#### Ссылки
[CardRequestBase - ](T_Tessa_Cards_CardRequestBase.htm)
[Tessa.Cards - пространство имён](N_Tessa_Cards.htm)
