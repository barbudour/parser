# Card.Clean - метод
Выполняет очистку хранилища от избыточных данных.
##  __Definition
 **Пространство имён:** [Tessa.Cards](N_Tessa_Cards.htm)  
 **Сборка:** Tessa (в Tessa.dll) Версия: 3.6.0.17
C# __Копировать
     public override void Clean()
VB __Копировать
     Public Overrides Sub Clean
C++ __Копировать
     public:
    virtual void Clean() override
F# __Копировать
     abstract Clean : unit -> unit 
    override Clean : unit -> unit 
#### Реализации
[IStorageCleanable.Clean()](M_Tessa_Platform_Storage_IStorageCleanable_Clean.htm)  
##  __См. также
#### Ссылки
[Card - ](T_Tessa_Cards_Card.htm)
[Tessa.Cards - пространство имён](N_Tessa_Cards.htm)
